<template>
  <main class="main-content">
    <BottomHeader>
      <template #actions>
        <!-- <q-btn icon="o_filter_alt" label="Filter" size="16px" color="white" text-color="primary" class="text-bold" no-caps
          push @click="onshowDropOffDialog" v-if="role == 'Security'" /> -->
      </template>
    </BottomHeader>
    <div style="margin-top: -4rem;" class="q-pa-lg">
      <div class="row q-col-gutter-x-lg">
        <div class="col-md-2">
          <q-card class="card-shadow">
            <q-btn icon="fa-solid fa-school" label="School Child Drop Off" v-ripple square
              class="q-pa-md primary-color-deep" size="23px" text-color="white" clickable push
              @click="onshowDropOffDialog" />
            <q-card-section class="text-subitle4">
              <q-separator class="q-mb-md  text-h6" />
              <strong>Parents or guardians dropping-off their wards at school </strong> <br>
            </q-card-section>
          </q-card>
          <q-card class="q-mt-lg card-shadow">
            <q-btn icon="fa-solid fa-children" label="School Child Pick Up" cover square
              class="q-pa-md primary-color-light" size="24px" text-color="white" clickable push
              @click="onshowPickUpDialog" />
            <q-card-section class="text-subitle4 ">
              <q-separator class="q-mb-md text-h6" />
              <strong>Parents or guardians picking-up their wards at school </strong> <br>
            </q-card-section>
          </q-card>
        </div>
        <div class="col-md-10">
          <my-search-box v-model="searchKey" :on-refresh="loadRecords" />
          <q-card flat class="card-shadow q-mt-lg">
            <q-card-section>
              <q-table :filter="searchKey" :loading="paginationUtil.loading" flat
                v-model:pagination="paginationUtil.pagination" :rows="studentStore.listOfAttendance.records"
                :columns="columns" row-key="requestId" padding>
                <template v-slot:body-cell-StudentName="props">
                  <q-td key="StudentName" :props="props">
                    <q-badge fill class="primary-color" style="height: 1.5rem;">{{
                      attendanceStudent(props.row?.studentId)
                    }}</q-badge>
                  </q-td>
                </template>
                <template v-slot:body-cell-ActivityType="props">
                  <q-td key="ActivityType" :props="props">
                    <q-badge v-if="props.row.activityType === 'Drop-Off'" outline color="positive" label="Drop-Off" />
                    <q-badge v-if="props.row.activityType === 'Pick-Up'" outline color="blue-8" label="Pick-Up" />
                  </q-td>
                </template>
                <template v-slot:body-cell-Status="props">
                  <q-td key="Status" :props="props">
                    <q-badge v-if="props.row.status === 'Verified'" fill color="positive" label="Successful" />
                  </q-td>
                </template>
                <template v-slot:body-cell-actions="props">
                  <q-td key="actions" :props="props" auto-width>
                    <div class="row wrap justify-between"></div>
                    <q-btn-dropdown color="grey-8" dense>
                      <q-list>
                        <q-separator />
                      </q-list>
                    </q-btn-dropdown>
                  </q-td>
                </template>
                <template v-slot:top-left>
                  <div class="text-h5">Attendance</div>
                </template>
              </q-table>
            </q-card-section>
          </q-card>
        </div>
      </div>
    </div>

  </main>
  <q-dialog v-model="showIdentityWizardDialog" rounded persistent :maximized="false" transition-show="slide-up"
    transition-hide="slide-down">
    <q-card style="width: 900px; max-width: 100vw;">
      <q-toolbar>
        <q-avatar>
          <q-icon name="fa-solid fa-school" color="indigo-10" size="30px" v-if="isPickUp == false" />
          <q-icon name="fa-solid fa-children" color="indigo-10" size="30px" v-if="isPickUp == true" />
        </q-avatar>
        <q-toolbar-title color="blue-9" v-if="isPickUp == false"><span class="text-weight-bold">Verify Student Drop
            Off</span></q-toolbar-title>
        <q-toolbar-title color="blue-9" v-if="isPickUp == true"><span class="text-weight-bold">Verify Student Pick
            Up</span></q-toolbar-title>
        <q-btn flat round dense icon="close" @click="closeDialogWizard" />

      </q-toolbar>
      <q-card-section>
        <q-card class="card-shadow q-ml-xl q-mr-xl">
          <q-card-section style="margin-top: 0.4rem;" v-if="studentPayload != null || studentPayload.firstName != ''">
            <q-item>
              <div class="row flex-center">
                <q-item-section class="col-12">
                  <q-item-label class="text-weight-bold" style="font-size: 1.5rem">
                    {{ studentPayload.studentNumber }} {{ studentPayload.firstName }} {{ studentPayload.lastName }}
                  </q-item-label>
                  <q-item-label caption lines="1" class="text-bold" style="font-size: 1rem">
                    {{ activityCheckMessage_ }}
                  </q-item-label>
                </q-item-section>
              </div>
            </q-item>
          </q-card-section>
        </q-card>
        <div class="">
          <q-stepper v-model="step" vertical color="primary" animated flat>
            <q-step :name="1" title="Search Student" icon="settings" :done="step > 1">
              <q-form @submit="step = 2" @reset="onReset">
                <div class="row q-col-gutter-x-lg  ">
                  <div class="col-md-12">
                    <q-select v-model="studentPayload" :options="studentOptions" label="Status" lazy-rules
                      transition-show="scale" transition-hide="scale" use-input input-debounce="0"
                      @filter="filterStudents" option-value="code"
                      :option-label="option => option.studentNumber + '  ' + option.firstName + ' ' + option.lastName"
                      behavior="default"
                      :rules="[val => (val !== undefined && val !== null && val.length > 0) || (studentPayload !== undefined) || 'Select a student or enter the student identification number']">
                      <q-tooltip anchor="center middle" self="bottom left">Select the student or search by student number
                      </q-tooltip>
                    </q-select>
                  </div>
                </div>
                <q-stepper-navigation>
                  <q-btn class="primary-color-deep text-white" type="submit" label="Proceed" :loading="loading"
                    :disable="stepOneProceedDisabled" />
                  <q-btn label="Clear All" @click="onReset()" class="q-ml-sm primary-color text-white" />
                </q-stepper-navigation>
              </q-form>
            </q-step>
            <q-step :name="2" title="Choose Parent or Delegate" icon="settings" :done="step > 2">
              <q-form @submit="onInitiateVerification()" @reset="onReset">
                <div class="row q-col-gutter-x-lg  ">
                  <div class="col-md-6">
                    <q-radio v-model="isParent" checked-icon="task_alt" unchecked-icon="panorama_fish_eye" val="parent"
                      label="Is Parent" />
                    <q-radio v-model="isParent" checked-icon="task_alt" unchecked-icon="panorama_fish_eye" val="delegate"
                      label="Is Delegate" />
                  </div>
                  <div class="col-md-6">
                    <q-select v-model="verifyPersonPayload" :options="parentOptions" label="Parent" lazy-rules
                      v-if="isParent == 'parent'" transition-show="scale" transition-hide="scale" use-input
                      input-debounce="0" behavior="menu"
                      :option-label="option => (option?.parent?.firstName || '') + ' ' + (option?.parent?.lastName || '') + ' - ' + (option?.parent?.type || '')"
                      :rules="[val => (val !== undefined && val !== null && val.length > 0) || (studentPayload !== undefined) || 'Select a parent']">
                      <q-tooltip anchor="center middle" self="bottom left">Select the student or search by student number
                      </q-tooltip>
                    </q-select>
                    <q-select v-model="verifyPersonPayload" :options="DelegateOptions" label="Delegate" lazy-rules
                      v-if="isParent != 'parent'" transition-show="scale" transition-hide="scale" use-input
                      input-debounce="0"
                      :option-label="option => (option?.authorizedDelegate?.firstName || '') + ' ' + (option?.authorizedDelegate?.lastName || '') + ' - ' + (option?.authorizedDelegate?.relationshipToChild || '')"
                      behavior="menu"
                      :rules="[val => (val !== undefined && val !== null && val.length > 0) || (studentPayload !== undefined) || 'Select a delegate']">
                      <q-tooltip anchor="center middle" self="bottom left">Select the student or search by student number
                      </q-tooltip>
                    </q-select>
                  </div>
                </div>
                <q-stepper-navigation>
                  <q-btn class="primary-color-deep text-white" label="Send Verification OTP" type="submit"
                    :loading="loading" :disable="sendOTPDisabled" />
                  <q-btn label="Back" @click="step = 1" class="q-ml-sm primary-color text-white" />
                </q-stepper-navigation>
              </q-form>
            </q-step>
            <q-step :name="3" title="Verify OTP" icon="settings" :done="step > 3">
              <q-form @submit="onProcessVerification" @reset="onReset">
                <div class="row q-col-gutter-x-lg  ">
                  <div class="col-md-12">
                    <q-input v-model="verifyOTPPayload.OTP" label="Enter Verification OTP *" lazy-rules :rules="[
                      (val) => (val && Number(val)) || 'Enter verification OTP ',
                      (val) => val.length == 6 || 'Must be 10 characters'
                    ]" maxlength="6" />
                  </div>
                </div>
                <q-stepper-navigation>
                  <q-btn class="primary-color-deep text-white" label="Verify OTP" type="submit" :loading="loading" />
                  <q-btn label="Back" @click="step = 2" class="q-ml-sm primary-color text-white" />
                </q-stepper-navigation>
              </q-form>
            </q-step>
            <q-step :name="4" title="Finish" icon="settings" :done="step > 4">
              <q-form>
                <div class="row q-col-gutter-x-lg  ">
                  <div class="col-md-12">
                    <q-img src="../..//assets/images/cm/verified1.svg" class="q-ml-sm q-mr-sm" fit="scale-down"
                      width="14rem" />
                  </div>
                </div>
                <q-stepper-navigation>
                  <q-btn class="primary-color-deep text-white" label="Finish" @click="closeDialogWizard" />
                </q-stepper-navigation>
              </q-form>
            </q-step>
          </q-stepper>
        </div>
      </q-card-section>
    </q-card>
  </q-dialog>
</template>

<script lang="ts" setup>
import { useMemberStore } from 'src/stores/student/student.store';
import { useContributionStore } from 'src/stores/contribution/contribution.store';
import { useDonationStore } from 'src/stores/donation/donation.store';
import BottomHeader from 'components/structure/BottomHeader.vue';
import MySearchBox from 'components/utils/MySearchBar.vue';
import { ref, onMounted, watch, computed, Ref } from 'vue';
import { LocalStorage, useQuasar } from 'quasar';
import AAStatusConstants from 'src/constants/aa-status.constants';
import PaginationUtil from 'src/utils/pagination.utils';
import FetchDataRequest from 'src/models/FetchDataRequest.model';
import { MemberRecords } from 'src/models/student/AllMembers.model';
import { useVolunteerStore } from 'src/stores/verification/verification.store';

// ------------------------------- GLOBAL DECLARATIONS --------------------------------- //
const $q = useQuasar();
const studentStore = useMemberStore();
const parentStore = useContributionStore();
const delegateStore = useDonationStore();
const verificationStore = useVolunteerStore();


const paginationUtil = ref(new PaginationUtil());

const searchKey = ref('');
const filter = ref(null);
const showIdentityWizardDialog = ref(false);
const loading = ref(false);
const step = ref(1);
const studentOptions = ref(studentStore.listOfMembers.records);
const activityType = ref('');
const sendOTPDisabled = ref(true);
const isDropOff = ref(true);
const stepOneProceedDisabled = ref(true);
const activityCheckMessage = ref('');
const activityCheckMessage_ = computed(() => {
  return activityCheckMessage.value;
});


const parentOptions = <any>computed(() => {
  const result = parentStore.listOfContributions.records.filter((record) => (record.parent?.studentId === studentPayload.value.studentId));
  return result;
});

const DelegateOptions = <any>computed(() => {

  const result = delegateStore.listOfDonations.records.filter((record) => (record.authorizedDelegate?.studentId === studentPayload.value.studentId));
  return result;
});

const closeDialogWizard = () => {
  showIdentityWizardDialog.value = !showIdentityWizardDialog.value
  if (studentPayload.value.firstName != '') {
    onReset();
  }
}


const isParent = ref('parent');

const username = <any>ref(null);
const role = <any>ref(null);
const fullName = <any>ref(null);
const firstName = <any>ref(null);
const lastName = <any>ref(null);
const email = <any>ref(null);

if (LocalStorage.has('username') || LocalStorage.has('role') || LocalStorage.has('fullName')) {
  username.value = LocalStorage.getItem('username');
  role.value = LocalStorage.getItem('role');
  firstName.value = LocalStorage.getItem('firstName');
  lastName.value = LocalStorage.getItem('lastName');
  email.value = LocalStorage.getItem('email');
  fullName.value = LocalStorage.getItem('fullName');
};

const showContributionDialog = ref(false);
const isPickUp = ref(false);
const selectedStudent = ref('');

const studentPayload = <any>ref(
  {
    studentId: '',
    classId: '',
    studentNumber: '',
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    gender: '',
    status: '',
    emergencyContact: '',
    location: '',
    nationality: '',
    createdBy: '',
    medicalConditions: '',
    createdAt: '',
    updatedAt: ''
  }
);
const verifyPersonPayload: Ref<any> = ref({
  email: '',
  phone: '',
  name: '',
  // Other properties...
});

const verifyOTPPayload = ref(
  {
    OTP: ''
  });

const initiateVerificationPayload = ref({
  email: '',
  name: '',
  phone: ''
})

const verifyVerificationPayload = ref({
  logId: '',
  verificationId: '',
  enteredOTP: '',
  activityType: '',
  authorizedName: '',
  classId: '',
  parentId: '',
  delegateId: '',
  createdBy: '',
  studentId: '',
  relation: '',
})




// ------------------------------- REQUEST PAYLOAD --------------------------------- //



// ------------------------------- MEMBER METHODS --------------------------------- //



const onInitiateVerification = async () => {
  loading.value = true;
  if (isParent.value == 'parent') {
    initiateVerificationPayload.value.email = verifyPersonPayload.value.parent.email;
    initiateVerificationPayload.value.name = verifyPersonPayload.value.parent.firstName + ' ' + verifyPersonPayload.value.parent.lastName;
    initiateVerificationPayload.value.phone = verifyPersonPayload.value.parent.phone;
  }
  if (isParent.value == 'delegate') {
    initiateVerificationPayload.value.email = verifyPersonPayload.value.authorizedDelegate.email;
    initiateVerificationPayload.value.name = verifyPersonPayload.value.authorizedDelegate.firstName + ' ' + verifyPersonPayload.value.authorizedDelegate.lastName;
    initiateVerificationPayload.value.phone = verifyPersonPayload.value.authorizedDelegate.phone;
  }
  const result = await verificationStore.initiateVerification(initiateVerificationPayload.value);
  loading.value = false;
  if (result.status == AAStatusConstants.SUCCESS) {
    step.value = 3;
    $q.notify({
      color: 'green-8',
      textColor: 'white',
      icon: 'cloud_done',
      position: 'top-right',
      message: `${result.message}`,
    });
  } else {
    step.value = 2;
    $q.notify({
      color: 'red-8',
      textColor: 'white',
      icon: 'close',
      position: 'top-right',
      message: `${result.message}`,
    });
  }
};

const onProcessVerification = async () => {
  loading.value = true;
  verifyVerificationPayload.value = {
    createdBy: username.value,
    logId: verificationStore?.intiateVerify?.logId,
    verificationId: verificationStore?.intiateVerify?.verificationId,
    enteredOTP: verifyOTPPayload.value.OTP,
    activityType: activityType.value,
    authorizedName: initiateVerificationPayload.value.name,
    classId: '',
    parentId: verifyPersonPayload?.value?.parent?.parentId ?? 'NA',
    delegateId: verifyPersonPayload.value?.authorizedDelegate?.delegateId ?? 'NA',
    studentId: studentPayload?.value?.studentId ?? 'NA',
    relation: verifyPersonPayload?.value?.parent?.type ?? verifyPersonPayload.value?.authorizedDelegate?.relationshipToChild
  };

  const result = await verificationStore.processVerification(verifyVerificationPayload.value);
  loading.value = false;

  if (result.status == AAStatusConstants.SUCCESS) {
    showContributionDialog.value = false;
    step.value = 4;
    loadRecords();
    $q.notify({
      color: 'green-8',
      textColor: 'white',
      icon: 'cloud_done',
      position: 'top-right',
      message: `${result.message}`,
    });
  } else {
    step.value = 3;
    $q.notify({
      color: 'red-8',
      textColor: 'white',
      icon: 'close',
      position: 'top-right',
      message: `${result.message}`,
    });
  }
};

watch(() => verifyPersonPayload.value, () => {
  if (verifyPersonPayload.value) {
    sendOTPDisabled.value = false;
  }
})

watch(() => studentPayload.value, () => {
  const todaysDate = new Date().toISOString().split('T')[0];
  if (studentPayload.value) {
    const studentId = studentPayload?.value?.studentId;
    const attendanceRecord = studentStore.listOfAttendance.records;
    var result = attendanceRecord.filter((record) => record.studentId === studentId);

    var todaysDropOff: any[] = result.filter((record) => {
      return record.activityType === 'Drop-Off' && record.authorizedDateTime?.split('T')[0] === todaysDate
    });
    var todaysPickUp: any[] = result.filter((record) => {
      return record.activityType === 'Pick-Up' && record.authorizedDateTime?.split('T')[0] === todaysDate
    });

    if (todaysDropOff.length > 0 && isDropOff.value == true)// If there is a drop off, disallow another drop off
    {
      stepOneProceedDisabled.value = true;
      activityCheckMessage.value = `There has been a drop-off for ${studentPayload?.value?.firstName} ${studentPayload?.value?.lastName} today.`;
    }
    if (todaysDropOff.length > 0 && isDropOff.value == false && todaysPickUp.length === 0)// If there is a drop off and NO pick up, disallow another drop off and allow pickup
    {
      stepOneProceedDisabled.value = false;
      activityCheckMessage.value = `You can perform pick-up for ${studentPayload?.value?.firstName} ${studentPayload?.value?.lastName} today.`;
    }
    if (todaysDropOff.length === 0 && todaysPickUp.length === 0 && isDropOff.value == true)// Allow only drop off
    {
      stepOneProceedDisabled.value = false;
      activityCheckMessage.value = `You can perform drop-off for ${studentPayload?.value?.firstName} ${studentPayload?.value?.lastName} today.`;
    }
    if (todaysDropOff.length === 0 && todaysPickUp.length === 0 && isDropOff.value == false)// Disallow only pick up
    {
      stepOneProceedDisabled.value = true;
      activityCheckMessage.value = `You cannot perform pick-up for ${studentPayload?.value?.firstName} ${studentPayload?.value?.lastName} today.`;
    }
    if (todaysDropOff.length > 0 && todaysPickUp.length > 0 && isDropOff.value == false)// Don't allow pickup
    {
      stepOneProceedDisabled.value = true;
      activityCheckMessage.value = `There has been a drop-off and pick-up for ${studentPayload?.value?.firstName} ${studentPayload?.value?.lastName} today.`;

    }
    if (todaysDropOff.length > 0 && todaysPickUp.length > 0)// If there is a drop off and a pickup, disallow another drop off and pick up
    {
      stepOneProceedDisabled.value = true;
      activityCheckMessage.value = `There has been a drop-off and pick-up for ${studentPayload?.value?.firstName} ${studentPayload?.value?.lastName} today.\n
       `;
    }
  }

})


const filterStudents = (input: string, update: (param: () => void) => void) => {
  if (!input || input.trim() === '') {
    update(() => {
      studentOptions.value = studentStore.listOfMembers.records;
    });
    return;
  }

  const needle = input.toLowerCase();
  update(() => {
    studentOptions.value = studentStore.listOfMembers?.records?.filter(record => {
      const studentNumberMatch = record?.studentNumber?.toLowerCase().includes(needle);
      const fullNameMatch = (record?.firstName + ' ' + record?.lastName)?.toLowerCase().includes(needle);
      selectedStudent.value = (record?.firstName + ' ' + record?.lastName?.toLowerCase().includes(needle));
      return studentNumberMatch || fullNameMatch;
    });
  });
};



const loadRecords = async () => {
  getAllStudents(),
    getAllStudentAttendance()
}

const getAllStudents = async () => {
  const fetchData = new FetchDataRequest<unknown>(searchKey.value, filter.value);
  await paginationUtil.value.initiate<unknown, MemberRecords>(
    studentStore.getAllStudents,
    fetchData,
  );
}

const getAllStudentAttendance = async () => {
  const fetchData = new FetchDataRequest<unknown>(searchKey.value, filter.value);
  await paginationUtil.value.initiate<unknown, MemberRecords>(
    studentStore.getAllStudentAttendance,
    fetchData,
  );
}



const onReset = () => {
  verifyVerificationPayload.value = {
    createdBy: '',
    logId: '',
    verificationId: '',
    enteredOTP: '',
    activityType: '',
    authorizedName: '',
    classId: '',
    parentId: '',
    delegateId: '',
    studentId: '',
    relation: ''
  },
    activityCheckMessage.value = '',
    stepOneProceedDisabled.value = true
}

// ------------------------------- HELPER METHODS --------------------------------- //

const onshowDropOffDialog = () => {
  isPickUp.value = false;
  showIdentityWizardDialog.value = true;
  step.value = 1;
  activityType.value = 'Drop-Off';
  isDropOff.value = true;
};

const onshowPickUpDialog = () => {
  isPickUp.value = true;
  showIdentityWizardDialog.value = true;
  step.value = 1;
  activityType.value = 'Pick-Up';
  isDropOff.value = false;

};

function formatCustomDate(dateString: string): string {
  // Parse the input date string into a Date object
  const inputDate = new Date(dateString);

  // Check if the inputDate is valid
  if (isNaN(inputDate.getTime())) {
    return 'Invalid Date';
  }

  // Get the day, month, year, hours, and minutes
  const day = inputDate.getDate();
  const monthNames = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul',
    'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  const month = monthNames[inputDate.getMonth()];
  const year = inputDate.getFullYear();
  const hours = inputDate.getHours();
  const minutes = inputDate.getMinutes();
  const ampm = hours >= 12 ? 'pm' : 'am';

  // Format the date string
  const formattedDate = `${day}th ${month}, ${year}, ${hours}:${minutes.toString().padStart(2, '0')} ${ampm}`;

  return formattedDate;
}



function attendanceStudent(studentId: string): string | null {
  const listOfStudents = studentStore?.listOfMembers?.records;

  if (!listOfStudents) {
    return null; // or handle the case when listOfStudents is undefined or null
  }
  var result = listOfStudents.filter((record) => record.studentId === studentId)[0];
  var fullName = result?.firstName + ' ' + result?.lastName + ' - ' + result?.studentNumber
  return fullName;
}

function attendanceParent(parentId: string): string | null {
  const listofParents = parentStore?.listOfContributions?.records;

  if (listofParents == null || listofParents.length === 0) {
    return null; // or handle the case when listofParents is undefined or empty
  }

  const result = listofParents.find((record) => record.parent?.parentId === parentId);

  if (result == null) {
    return 'NA'; // or handle the case when the parent with parentId is not found
  }

  const fullName = `${result.parent?.firstName ?? ''} ${result.parent?.lastName ?? ''} - ${result.parent?.type ?? ''}`;

  return fullName.trim() || 'NA'; // trim to handle cases where parts of the name or type might be undefined or null
}


function attendanceDelegate(delegateId: string): string | null {
  const listOfDelegates = delegateStore?.listOfDonations?.records;

  if (listOfDelegates == null || listOfDelegates.length === 0) {
    return 'Joshua'; // or handle the case when listOfDelegates is undefined or empty
  }

  const result = listOfDelegates.find((record) => record.authorizedDelegate?.delegateId === delegateId);

  if (result == null) {
    return 'NA'; // or handle the case when the delegate with delegateId is not found
  }

  const fullName = `${result.authorizedDelegate?.firstName ?? ''} ${result.authorizedDelegate?.lastName ?? ''} - ${result.authorizedDelegate?.relationshipToChild ?? ''}`;

  return fullName.trim() || 'NA'; // trim to handle cases where parts of the name or relationship might be undefined or null
}

// ------------------------------- TABLE COLUMNS AND ROWS --------------------------------- //

const columns: any = ([
  { name: 'actions', align: 'center', label: 'Action' },
  {
    name: 'StudentName',
    required: true,
    label: 'Student',
    align: 'center',
    field: (row: any) => {
      return attendanceStudent(row?.studentId);
    }
  },
  {
    name: 'ParentName',
    required: true,
    label: 'Parent',
    align: 'center',
    field: (row: any) => {
      return attendanceParent(row?.parentId);
    }
  },
  {
    name: 'DelegateName',
    required: true,
    label: 'Delegate',
    align: 'center',
    field: (row: any) => {
      return attendanceDelegate(row?.delegateId);
    }
  },
  { name: 'Status', label: 'Verification Status', align: 'center', field: 'status' },
  {
    name: 'AuthorizedTimestamp', label: 'Authorized Timestamp', align: 'left', field: (row: any) => {
      return formatCustomDate(row?.authorizedDateTime);
    }
  },
  { name: 'ActivityType', align: 'left', label: 'Activity Type', field: 'activityType' },
  {
    name: 'DateCreated', align: 'left', label: 'Date Created', field: (row: any) => {
      return formatCustomDate(row?.createdAt);
    }
  },

]);

// ------------------------------- ON MOUNTED --------------------------------- //

onMounted(() => {
  loadRecords()
});

</script>

<style scoped>
.text-white {
  color: #FFFFFF;
}
</style>

