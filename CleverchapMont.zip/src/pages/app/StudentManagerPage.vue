<template>
  <main class="main-content">
    <BottomHeader>
      <template #actions>
        <q-btn icon="person_add_alt" label="New Student" size="16px" color="white" text-color="primary" class="text-bold"
          no-caps push @click="onshowCreateMemberDialog" />
      </template>
    </BottomHeader>
    <div style="margin-top: -4rem;" class="q-pa-lg">
      <div class="row">
        <div class="col-12 ">
          <my-search-box v-model="searchKey" :on-refresh="loadRecords" />
          <q-table style="margin-top: 2rem;" title="Students" flat :filter="searchKey" :loading="paginationUtil.loading"
            v-model:pagination="paginationUtil.pagination" :rows="memberList" :columns="columns" row-key="studentId"
            padding>
            <template v-slot:body-cell-StudentStatus="props">
              <q-td key="StudentStatus" :props="props">
                <q-badge v-if="props.row.status === 'Active'" class="q-pl-md q-pr-md" label="Active" fill color="green-8"
                  style="height: 1.5rem;" />

                <q-badge v-if="props.row.status === 'Inactive'" class="q-pl-md q-pr-md" label="Inactive" fill
                  color="yellow-8" style="height: 1.5rem;" />

                <q-badge v-if="props.row.status === 'Deleted'" class="q-pl-md q-pr-md" label="Deleted" fill color="red-7"
                  style="height: 1.5rem;" />
              </q-td>
            </template>

            <template v-slot:body-cell-StudentNumber="props">
              <q-td key="StudentNumber" :props="props">
                <q-badge fill class="primary-color" style="height: 1.5rem;">{{ props.row.studentNumber }}</q-badge>
              </q-td>
            </template>

            <template v-slot:body-cell-Gender="props">
              <q-td key="Gender" :props="props">
                <div v-if="props.row.gender === 'male'" class="q-pl-md q-pr-md">Male</div>
                <div v-if="props.row.gender === 'female'" class="q-pl-md q-pr-md">Female</div>
              </q-td>
            </template>

            <template v-slot:body-cell-actions="props">
              <q-td key="actions" :props="props" auto-width>
                <div class="row wrap justify-between"></div>
                <q-btn-dropdown color="grey-8" dense>
                  <q-list>
                    <q-item clickable @click="onshowUpdateMemberDialog(props.row as MemberRecords)">
                      <q-item-section side>
                        <q-icon name="o_edit_note" />
                      </q-item-section>
                      <q-item-section>
                        <q-item-label>Update Student</q-item-label>
                      </q-item-section>
                    </q-item>
                    <q-item clickable @click="gotoMemberHistory(props.row as MemberRecords)">
                      <q-item-section side>
                        <q-icon name="o_history" />
                      </q-item-section>
                      <q-item-section>
                        <q-item-label>Attendance History</q-item-label>
                      </q-item-section>
                    </q-item>
                    <q-separator />
                    <q-item clickable @click="onshowCreateParentDialog(props.row as MemberRecords)">
                      <q-item-section side>
                        <q-icon name="o_supervisor_account" />
                      </q-item-section>
                      <q-item-section>
                        <q-item-label>Add Parent</q-item-label>
                      </q-item-section>
                    </q-item>
                    <q-item clickable @click="onshowCreateDelegateDialog(props.row as MemberRecords)">
                      <q-item-section side>
                        <q-icon name="o_escalator_warning" />
                      </q-item-section>
                      <q-item-section>
                        <q-item-label>Add Delegate</q-item-label>
                      </q-item-section>
                    </q-item>
                  </q-list>
                </q-btn-dropdown>
              </q-td>
            </template>
          </q-table>
        </div>
        <div class="q-pt-lg">
        </div>
      </div>
    </div>

  </main>
  <q-dialog v-model="showStudentDialog" rounded style="width: 100% !important;" persistent>
    <q-card style="width: 900px; max-width: 100vw;">
      <q-toolbar>
        <q-avatar>
          <q-icon name="person_add_alt" color="blue-9" size="30px" v-if="isUpdate == false" />
          <q-icon name="edit" color="blue-9" size="30px" v-if="isUpdate == true" />
        </q-avatar>
        <q-toolbar-title color="blue-9" v-if="isUpdate == false"><span class="text-weight-bold">Add
            Student</span></q-toolbar-title>
        <q-toolbar-title color="blue-9" v-if="isUpdate == true"><span class="text-weight-bold">Update
            Student</span></q-toolbar-title>
        <q-btn flat round dense icon="close" v-close-popup />
      </q-toolbar>
      <q-card-section>
        <q-card class="card-shadow q-ml-xl q-mr-xl" v-if="isUpdate == true">
          <q-card-section style="margin-top: 0.4rem;" class="row justify-between">
            <q-item>
              <div class="row ">
                <q-item-section class="col-12">
                  <q-item-label class="text-weight-bold" style="font-size: 1.5rem; text-align: center;">
                    {{ selectedStudentPayload.firstName }} {{ selectedStudentPayload.lastName }} - {{
                      selectedStudentPayload.studentNumber }} - {{ selectedStudentPayload.nationality.toUpperCase() }}
                  </q-item-label>
                </q-item-section>
              </div>
            </q-item>
          </q-card-section>
        </q-card>
        <div class="">
          <q-stepper v-model="step" vertical color="primary" animated flat>
            <q-step :name="1" title="Personal Information" icon="settings" :done="step > 1">
              <q-form @submit="onProcessStudent" @reset="onReset">
                <div class="row q-col-gutter-x-lg  ">
                  <div class="col-md-6">
                    <q-input v-model="studentPayload.firstName" label="First Name *" lazy-rules
                      :rules="[val => val && val.length > 0 || 'Enter the student\'s first name']" />
                  </div>
                  <div class="col-md-6">
                    <q-input v-model="studentPayload.lastName" label="Last Name *" lazy-rules
                      :rules="[val => val && val.length > 0 || 'Enter the student\'s last name']" />
                  </div>
                  <!-- <div class="col-md-6">
                    <q-input v-model="memberPayload.emailAddress" label="Email Address " type="email" lazy-rules :rules="[
                      (val) => (val && /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(val)) || 'Must be a valid email address'
                    ]" /> -->
                  <div class="col-md-6">
                    <q-input v-model="studentPayload.location" label="Address *" lazy-rules
                      :rules="[val => val && val.length > 0 || 'Enter the address of the student']" />
                  </div>
                  <div class="col-md-6">
                    <q-input v-model="studentPayload.nationality" label="Nationality *" lazy-rules
                      :rules="[val => val && val.length > 0 || 'Enter the nationality of the student']" />
                  </div>
                  <div class="col-md-6">
                    <q-input v-model="studentPayload.emergencyContact" type="number" hint="+233 (XXX) XXX - XXX" autogrow
                      label="Emergency Contact *" :rules="[
                        (val) => (val && Number(val)) || 'Enter the emergency contact of the student',
                        (val) => val.length == 10 || 'Must be 10 characters'
                      ]">
                      <q-tooltip anchor="center middle" self="bottom left">Emergency Contact
                      </q-tooltip>
                    </q-input>
                  </div>
                  <div class="col-md-6 q-mt-lg">
                    <q-radio dense v-model="studentPayload.gender" val="male" label="Male" class="q-mr-lg" />
                    <q-radio dense v-model="studentPayload.gender" val="female" label="Female" />
                  </div>
                  <div class="col-md-6">
                    <q-input v-model="studentPayload.medicalConditions" label="Medical Conditions" lazy-rules />
                  </div>
                  <div class="col-md-6" v-if="isUpdate == true">
                    <q-select v-model="studentPayload.status" :options="studentStatusOptions" label="Status" lazy-rules
                      transition-show="scale" transition-hide="scale" behavior="default"
                      :rules="[(val) => (val && val.length > 0) || 'Select Student Status']">
                      <q-tooltip anchor="center middle" self="bottom left">Select the student status
                      </q-tooltip>
                    </q-select>
                  </div>
                  <div class="col-md-6">
                    <q-input v-model="studentPayload.dateOfBirth"
                      :rules="[(val) => (val && val.length > 0) || 'Choose Student\'s Date of Birth']"
                      label="Date of Birth">
                      <template v-slot:append>
                        <q-icon name="event" class="cursor-pointer">
                          <q-popup-proxy cover transition-show="scale" transition-hide="scale">
                            <q-date v-model="studentPayload.dateOfBirth" mask="YYYY-MM-DD">
                              <div class="row items-center justify-end">
                                <q-btn v-close-popup label="Close" color="primary" flat />
                              </div>
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </div>
                <q-stepper-navigation>
                  <q-btn color="primary" label="Onboard Student" type="submit" :loading="loading"
                    v-if="isUpdate == false" />
                  <q-btn color="primary" label="Update Student" type="submit" v-if="isUpdate == true"
                    :loading="loading" />
                  <q-btn color="dark" flat label="Clear All" @click="onReset()" class="q-ml-sm" />
                </q-stepper-navigation>

              </q-form>
            </q-step>
          </q-stepper>
        </div>
      </q-card-section>
    </q-card>
  </q-dialog>
  <q-dialog v-model="showParentDialog" rounded style="width: 100% !important;">
    <q-card style="width: 900px; max-width: 100vw;">
      <q-toolbar>
        <q-avatar>
          <q-icon name="fa-solid fa-hand-holding-dollar" color="blue-9" size="30px" v-if="isUpdate == false" />
          <q-icon name="edit" color="blue-9" size="30px" v-if="isUpdate == true" />
        </q-avatar>
        <q-toolbar-title color="blue-9" v-if="isUpdate == false"><span class="text-weight-bold">Add
            Parent</span></q-toolbar-title>
        <q-toolbar-title color="blue-9" v-if="isUpdate == true"><span class="text-weight-bold">Update
            Parent</span></q-toolbar-title>
        <q-btn flat round dense icon="close" v-close-popup />
      </q-toolbar>
      <q-card-section>
        <q-card class="card-shadow q-ml-xl q-mr-xl">
          <q-card-section style="margin-top: 0.4rem;">
            <q-item>
              <div class="row flex-center">
                <q-item-section class="col-12">
                  <q-item-label class="text-weight-bold" style="font-size: 1.5rem">
                    {{ selectedStudentPayload.firstName }} {{ selectedStudentPayload.lastName }} - {{
                      selectedStudentPayload.studentNumber }} - {{ selectedStudentPayload.nationality.toUpperCase() }}
                  </q-item-label>
                </q-item-section>
              </div>
            </q-item>
          </q-card-section>
        </q-card>
        <div class="">
          <q-stepper v-model="step" vertical color="primary" animated flat>
            <q-step :name="1" title="Add a new parent for the student above" :done="step > 1">
              <q-form @submit="onProcessNewParent" @reset="onReset">
                <div class="row q-col-gutter-x-lg  ">
                  <div class="col-md-6">
                    <q-input v-model="parentPayload.firstName" label="First Name *" lazy-rules
                      :rules="[val => val && val.length > 0 || 'Enter the parent\'s first name']" />
                  </div>
                  <div class="col-md-6">
                    <q-input v-model="parentPayload.lastName" label="Last Name *" lazy-rules
                      :rules="[val => val && val.length > 0 || 'Enter the parent\'s last name']" />
                  </div>
                  <div class="col-md-12">
                    <q-input v-model="parentPayload.emailAddress" label="Email Address " type="email" lazy-rules :rules="[
                      (val) => (val && /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(val)) || 'Must be a valid email address'
                    ]" />
                  </div>
                  <div class="col-md-6">
                    <q-input v-model="parentPayload.phoneNumber" type="number" hint="+233 (XXX) XXX - XXX" autogrow
                      label="Contact *" :rules="[
                        (val) => (val && Number(val)) || 'Enter the contact number of the parent',
                        (val) => val.length == 10 || 'Must be 10 characters'
                      ]">
                      <q-tooltip anchor="center middle" self="bottom left">Contact
                      </q-tooltip>
                    </q-input>
                  </div>
                  <div class="col-md-6 q-mt-lg">
                    <q-radio dense v-model="parentPayload.type" val="Father" label="Father" class="q-mr-lg" />
                    <q-radio dense v-model="parentPayload.type" val="Mother" label="Mother" />
                  </div>
                  <div class="col-md-6">
                    <q-input v-model="parentPayload.location" label="Address *" lazy-rules
                      :rules="[val => val && val.length > 0 || 'Enter the address of the parent']" />
                  </div>
                  <div class="col-md-6">
                    <q-input v-model="parentPayload.nationality" label="Nationality *" lazy-rules
                      :rules="[val => val && val.length > 0 || 'Enter the nationality of the parent']" />
                  </div>

                  <q-stepper-navigation>
                    <q-btn color="primary" label="Add Parent" type="submit" :loading="loading" v-if="isUpdate == false"
                      class="q-mr-md" />
                    <q-btn color="primary" label="Update Parent" :loading="loading" type="submit" v-if="isUpdate == true"
                      class="q-mr-md" />
                    <q-btn color="dark" label="Clear All" @click="onReset()" />
                  </q-stepper-navigation>
                </div>
              </q-form>
            </q-step>
          </q-stepper>
        </div>
      </q-card-section>
    </q-card>
  </q-dialog>
  <q-dialog v-model="showDelegateDialog" rounded style="width: 100% !important;">
    <q-card style="width: 900px; max-width: 100vw;">
      <q-toolbar>
        <q-avatar>
          <q-icon name="fa-solid fa-gift" color="blue-9" size="30px" v-if="isUpdate == false" />
          <q-icon name="edit" color="blue-9" size="30px" v-if="isUpdate == true" />
        </q-avatar>
        <q-toolbar-title color="blue-9" v-if="isUpdate == false"><span class="text-weight-bold">Add
            Delegate</span></q-toolbar-title>
        <q-toolbar-title color="blue-9" v-if="isUpdate == true"><span class="text-weight-bold">Update
            Delegate</span></q-toolbar-title>
        <q-btn flat round dense icon="close" v-close-popup />
      </q-toolbar>
      <q-card-section>
        <q-card class="card-shadow q-ml-xl q-mr-xl">
          <q-card-section style="margin-top: 0.4rem;">
            <q-item>
              <div class="row flex-center">
                <q-item-section class="col-12">
                  <q-item-label class="text-weight-bold" style="font-size: 1.5rem">
                    {{ selectedStudentPayload.firstName }} {{ selectedStudentPayload.lastName }} - {{
                      selectedStudentPayload.studentNumber }} - {{ selectedStudentPayload.nationality.toUpperCase() }}
                  </q-item-label>
                </q-item-section>
              </div>
            </q-item>
          </q-card-section>
        </q-card>
        <div class="">
          <q-stepper v-model="step" vertical color="primary" animated flat>
            <q-step :name="1" title="Add a new donation for the student above" :done="step > 1">
              <q-form @submit="onProcessNewDelegation" @reset="onReset">
                <div class="row q-col-gutter-x-lg  ">
                  <div class="col-md-6">
                    <q-input v-model="delegatePayload.firstName" label="First Name *" lazy-rules
                      :rules="[val => val && val.length > 0 || 'Enter the delegate\'s first name']" />
                  </div>
                  <div class="col-md-6">
                    <q-input v-model="delegatePayload.lastName" label="Last Name *" lazy-rules
                      :rules="[val => val && val.length > 0 || 'Enter the delegate\'s last name']" />
                  </div>
                  <div class="col-md-12">
                    <q-input v-model="delegatePayload.emailAddress" label="Email Address " type="email" lazy-rules :rules="[
                      (val) => (val && /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(val)) || 'Must be a valid email address'
                    ]" />
                  </div>
                  <div class="col-md-6">
                    <q-input v-model="delegatePayload.phoneNumber" type="number" hint="+233 (XXX) XXX - XXX" autogrow
                      label="Contact *" :rules="[
                        (val) => (val && Number(val)) || 'Enter the contact number of the delegate',
                        (val) => val.length == 10 || 'Must be 10 characters'
                      ]">
                      <q-tooltip anchor="center middle" self="bottom left">Contact
                      </q-tooltip>
                    </q-input>
                  </div>

                  <div class="col-md-6">
                    <q-select v-model="delegatePayload.relationshipToChild" :options="relationshipToChildOptions"
                      label="Relationship to Child" lazy-rules transition-show="scale" transition-hide="scale"
                      behavior="default"
                      :rules="[(val: string | any[]) => (val && val.length > 0) || 'Select Relationship to Child']">
                      <q-tooltip anchor="center middle" self="bottom left">Select the relationship to child
                      </q-tooltip>
                    </q-select>
                  </div>
                </div>
                <q-stepper-navigation>
                  <q-btn color="primary" label="Add Delegate" type="submit" :loading="loading" v-if="isUpdate == false"
                    class="q-mr-md" />
                  <q-btn color="dark" label="Clear All" @click="onReset()" />
                </q-stepper-navigation>
              </q-form>
            </q-step>
          </q-stepper>
        </div>
      </q-card-section>
    </q-card>
  </q-dialog>
  <q-dialog v-model="confirmStudentDialog" persistent>
    <q-card>
      <q-card-section class="row items-center">
        <div class="col">
          <q-avatar icon="o_delete" color="primary" text-color="white" />
          <span class="q-ml-sm">Do you really want to mark this student as deleted?</span>
        </div>
      </q-card-section>
      <q-card-actions align="right">
        <q-btn flat label="Cancel" color="primary" v-close-popup />
        <q-btn flat label="Mark as Delete" color="primary" @click="onProcessSoftDeleteMember()" />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script lang="ts" setup>
import { useAuthStore } from 'src/stores/auth/auth-store';
import { useMemberStore } from 'src/stores/student/student.store';
import { useContributionStore } from 'src/stores/contribution/contribution.store';
import { useDonationStore } from 'src/stores/donation/donation.store';
import BottomHeader from 'components/structure/BottomHeader.vue';
import MySearchBox from 'components/utils/MySearchBar.vue';
import { useRouter } from 'vue-router';
import { ref, onMounted, watch, computed } from 'vue';
import { LocalStorage, date, useQuasar } from 'quasar';
import AAStatusConstants from 'src/constants/aa-status.constants';
import PaginationUtil from 'src/utils/pagination.utils';
import FetchDataRequest from 'src/models/FetchDataRequest.model';
import { MemberRecords } from 'src/models/student/AllMembers.model';
import { useRoute } from 'vue-router';


// ------------------------------- GLOBAL DECLARATIONS --------------------------------- //
const $q = useQuasar();
const router = useRouter();
const authStore = useAuthStore();
const studentStore = useMemberStore();
const parentStore = useContributionStore();
const delegateStore = useDonationStore();
const paginationUtil = ref(new PaginationUtil());
const searchKey = ref('');
const filter = ref(null);
const showStudentDialog = ref(false);
const confirmStudentDialog = ref(false);
const loading = ref(false);
const step = ref(1);
const studentStatusOptions = ref(['Active', 'Inactive', 'Deleted']);
const relationshipToChildOptions = ref(['Brother', 'Sister', 'Other', 'Uncle', 'Guardian', 'Auntie', 'Other']);

const showParentDialog = ref(false);
const showDelegateDialog = ref(false);
const isUpdate = ref(false);

const studentId = ref('');
const route = useRoute();

const username = <any>ref(null);

if (LocalStorage.has('username')) {
  username.value = LocalStorage.getItem('username');
};



// ------------------------------- REQUEST PAYLOAD --------------------------------- //

const parentPayload = ref(
  {
    studentId: '',
    firstName: '',
    lastName: '',
    location: '',
    nationality: '',
    emailAddress: '',
    type: '',
    phoneNumber: '',
    createdBy: username.value,
  });

const delegatePayload = ref(
  {
    studentId: '',
    firstName: '',
    lastName: '',
    emailAddress: '',
    relationshipToChild: '',
    phoneNumber: '',
    createdBy: username.value,
  });


const memberPayload = ref(
  {
    firstName: '',
    middleName: '',
    lastName: '',
    photograph: '',
    age: '',
    dateOfBirth: '',
    gender: '',
    emailAddress: '',
    phoneNumber: '',
    emergencyContact: '',
    dateJoined: '',
    maritalStatus: '',
    membershipStatus: '',
    children: '',
    occupation: '',
    membershipType: '',
    additionalInformation: '',
    createdBy: username.value,
    location: '',
  });

const studentPayload = ref({
  firstName: '',
  lastName: '',
  dateOfBirth: '',
  gender: '',
  emergencyContact: '',
  location: '',
  nationality: '',
  medicalConditions: '',
  studentId: '',
  createdBy: username.value,
  status: ''
});

const selectedStudentPayload = ref(
  {
    firstName: '',
    lastName: '',
    studentNumber: '',
    nationality: '',
    gender: ''
  });

// ------------------------------- MEMBER METHODS --------------------------------- //

const memberList = computed(() => {
  return studentStore.listOfMembers?.records.filter((record: any) => (record.isDeleted != 'deleted'));
});

const onProcessStudent = async () => {
  if (isUpdate.value == false) {
    onProcessNewStudent();
  }
  else {
    onProcessUpdateStudent();
  }
};

const onProcessNewParent = async () => {
  loading.value = true;
  parentPayload.value.studentId = studentId.value;
  const result = await parentStore.createParent(parentPayload.value);
  loading.value = false;

  if (result.status == AAStatusConstants.SUCCESS) {
    showParentDialog.value = false;
    step.value = 1;
    loadRecords();
    $q.notify({
      color: 'green-8',
      textColor: 'white',
      icon: 'cloud_done',
      position: 'top-right',
      message: `${result.message}`,
    });
  } else {
    $q.notify({
      color: 'red-8',
      textColor: 'white',
      icon: 'close',
      position: 'top-right',
      message: `${result.message}`,
    });
  }
};

const onProcessNewDelegation = async () => {
  loading.value = true;
  delegatePayload.value.studentId = studentId.value;
  const result = await delegateStore.createDelegate(delegatePayload.value);
  loading.value = false;
  if (result.status == AAStatusConstants.SUCCESS) {
    showDelegateDialog.value = false;
    step.value = 1;
    loadRecords();
    $q.notify({
      color: 'green-8',
      textColor: 'white',
      icon: 'cloud_done',
      position: 'top-right',
      message: `${result.message}`,
    });
  } else {
    $q.notify({
      color: 'red-8',
      textColor: 'white',
      icon: 'close',
      position: 'top-right',
      message: `${result.message}`,
    });
  }
};

const onProcessNewStudent = async () => {
  loading.value = true;
  const result = await studentStore.createStudent(studentPayload.value);
  loading.value = false;
  if (result.status == AAStatusConstants.SUCCESS) {
    showStudentDialog.value = false;
    step.value = 1;
    onReset();
    loadRecords();
    $q.notify({
      color: 'green-8',
      textColor: 'white',
      icon: 'cloud_done',
      position: 'top-right',
      message: `${result.message}`,
    });
  } else {
    $q.notify({
      color: 'red-8',
      textColor: 'white',
      icon: 'close',
      position: 'top-right',
      message: `${result.message}`,
    });
  }
};

const onProcessUpdateStudent = async () => {
  loading.value = true;
  const result = await studentStore.editStudent(studentPayload.value);
  loading.value = false;
  if (result.status == AAStatusConstants.SUCCESS) {
    showStudentDialog.value = false;
    step.value = 1;
    loadRecords();
    $q.notify({
      color: 'green-8',
      textColor: 'white',
      icon: 'cloud_done',
      position: 'top-right',
      message: `${result.message}`,
    });
  } else {
    $q.notify({
      color: 'red-8',
      textColor: 'white',
      icon: 'close',
      position: 'top-right',
      message: `${result.message}`,
    });
  }
};


const onProcessSoftDeleteMember = async () => {
  loading.value = true;

  const result = await studentStore.softDeleteMember({
    memberID: studentId.value
  });
  loading.value = false;
  if (result.status == AAStatusConstants.SUCCESS) {
    confirmStudentDialog.value = false;
    $q.notify({
      color: 'green-8',
      textColor: 'white',
      icon: 'cloud_done',
      position: 'top-right',
      message: `${result.message}`,
    });
  } else {
    $q.notify({
      color: 'red-8',
      textColor: 'white',
      icon: 'close',
      position: 'top-right',
      message: `${result.message}`,
    });
  }
};

const gotoMemberHistory = (student: any) => {
  router.push(`/welfare/members-history/${student.studentId}`);
};


const memberInfo = computed(() => {
  return studentStore.listOfMembers?.records.filter((record: any) => (record.studentId === route.params['']))[0];
  // return studentStore?.listOfMembers.records?.filter((record) => (record.records === route.params['']))[0];
});

const loadRecords = async () => {
  getAllStudents()

}

const getAllStudents = async () => {
  const fetchData = new FetchDataRequest<unknown>(searchKey.value, filter.value);
  await paginationUtil.value.initiate<unknown, MemberRecords>(
    studentStore.getAllStudents,
    fetchData,
  );
}

const onReset = () => {
  studentPayload.value = {
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    gender: '',
    emergencyContact: '',
    medicalConditions: '',
    nationality: '',
    createdBy: authStore.listOfUserInfo.username,
    location: '',
    studentId: '',
    status: ''
  }
}

// ------------------------------- HELPER METHODS --------------------------------- //

const onshowCreateMemberDialog = () => {
  isUpdate.value = false;
  showStudentDialog.value = true;
};


const onshowUpdateMemberDialog = (student: any) => {
  isUpdate.value = true;
  memberPayload.value = {
    firstName: student.firstName,
    middleName: student.middleName,
    lastName: student.lastName,
    photograph: '',
    age: student.age,
    dateOfBirth: student.dateOfBirth,
    gender: student.gender,
    emailAddress: student.emailAddress,
    phoneNumber: student.phoneNumber,
    emergencyContact: student.emergencyContact,
    dateJoined: student.dateJoined,
    maritalStatus: student.maritalStatus,
    membershipStatus: student.membershipStatus,
    children: student.children,
    occupation: student.occupation,
    membershipType: student.membershipType,
    additionalInformation: student.additionalInformation,
    createdBy: username.value,
    location: student.location,
  };
  selectedStudentPayload.value = {
    firstName: student.firstName,
    lastName: student.lastName,
    nationality: student.nationality,
    studentNumber: student.studentNumber,
    gender: student.gender
  };
  studentPayload.value = {
    firstName: student.firstName,
    lastName: student.lastName,
    dateOfBirth: student.dateOfBirth,
    gender: student.gender,
    emergencyContact: student.emergencyContact,
    location: student.location,
    nationality: student.nationality,
    medicalConditions: student.medicalConditions,
    createdBy: username.value,
    studentId: student.studentId,
    status: ''
  }
  showStudentDialog.value = true;
};


const onshowCreateParentDialog = (student: any) => {
  isUpdate.value = false;
  showParentDialog.value = true;
  selectedStudentPayload.value = {
    firstName: student.firstName,
    lastName: student.lastName,
    nationality: student.nationality,
    studentNumber: student.studentNumber,
    gender: student.gender
  };
  studentId.value = student.studentId;
};

const onshowCreateDelegateDialog = (student: any) => {
  isUpdate.value = false;
  showDelegateDialog.value = true;
  selectedStudentPayload.value = {
    firstName: student.firstName,
    lastName: student.lastName,
    nationality: student.nationality,
    studentNumber: student.studentNumber,
    gender: student.gender
  };
  studentId.value = student.studentId;
};


// const onshowUpdateContributionDialog = (student: any) => {
//   isUpdate.value = true;
//   showParentDialog.value = true;
// };


const onshowConfirmationDialog = (student: any) => {
  confirmStudentDialog.value = true;
  studentId.value = student.studentId;
};


// ------------------------------- TABLE COLUMNS AND ROWS --------------------------------- //

function formatCustomDate(dateString: string): string {
  // Parse the input date string into a Date object
  const inputDate = new Date(dateString);

  // Check if the inputDate is valid
  if (isNaN(inputDate.getTime())) {
    return 'Invalid Date';
  }

  // Get the day, month, year, hours, and minutes
  const day = inputDate.getDate();
  const monthNames = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul',
    'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  const month = monthNames[inputDate.getMonth()];
  const year = inputDate.getFullYear();
  const hours = inputDate.getHours();
  const minutes = inputDate.getMinutes();
  const ampm = hours >= 12 ? 'pm' : 'am';

  // Format the date string
  const formattedDate = `${day}th ${month}, ${year}, ${hours}:${minutes.toString().padStart(2, '0')} ${ampm}`;

  return formattedDate;
}


const columns: any = ([
  { name: 'actions', align: 'center', label: 'Action' },
  {
    name: 'name',
    required: true,
    label: 'Full Name',
    align: 'left',
    field: (row: any) => {
      return row?.firstName + ' ' + row?.lastName ?? 0;
    },
  },
  { name: 'StudentNumber', label: 'Student Number', align: 'left', field: 'studentNumber' },
  { name: 'Date of Birth', align: 'left', label: 'Date Of Birth', field: 'dateOfBirth' },
  { name: 'Gender', align: 'left', label: 'Gender', field: 'gender' },
  { name: 'StudentStatus', align: 'center', label: 'Student Status', field: 'status' },
  { name: 'Location', align: 'left', label: 'Location', field: 'location' },
  { name: 'Nationality', align: 'left', label: 'Nationality', field: 'nationality' },
  { name: 'EmergencyContact', align: 'left', label: 'Emergency Contact', field: 'emergencyContact' },
  {
    name: 'DateCreated', align: 'left', label: 'Date Created', field: (row: any) => {
      return formatCustomDate(row?.createdAt);
    }
  },
  { name: 'CreatedBy', label: 'Created By', align: 'left', field: 'createdBy' },

]);

// ------------------------------- ON MOUNTED --------------------------------- //

onMounted(() => {
  loadRecords()
});

</script>

<style scoped></style>

