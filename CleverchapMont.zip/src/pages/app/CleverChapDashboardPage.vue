<template>
  <main class="main-content">
    <BottomHeader>
      <template #actions>
        <q-btn icon="how_to_reg" label="Verify Identity" size="16px" color="white" text-color="primary-color"
          class="text-bold" no-caps push @click="goToIdentityVerificationPage" v-if="role == 'Security'" />
      </template>
    </BottomHeader>
    <MainContainer />
  </main>
</template>

<script lang="ts" setup>
import { useMemberStore } from 'src/stores/student/student.store';
import { useContributionStore } from 'src/stores/contribution/contribution.store';
import { useDonationStore } from 'src/stores/donation/donation.store';
import BottomHeader from 'components/structure/BottomHeader.vue';
import MainContainer from 'components/main/MainContainer.vue';
import { useRouter } from 'vue-router';
import { ref, onMounted, } from 'vue';
import PaginationUtil from 'src/utils/pagination.utils';
import FetchDataRequest from 'src/models/FetchDataRequest.model';
import { MemberRecords } from 'src/models/student/AllMembers.model';
import { LocalStorage } from 'quasar';


const router = useRouter();
const studentStore = useMemberStore();
const contributionStore = useContributionStore();
const donationStore = useDonationStore();

const paginationUtil = ref(new PaginationUtil());
const searchKey = ref('');
const filter = ref(null);

const username = <any>ref(null);
const role = <any>ref(null);
const fullName = <any>ref(null);
const firstName = <any>ref(null);
const lastName = <any>ref(null);
const email = <any>ref(null);


if (LocalStorage.has('username') || LocalStorage.has('role') || LocalStorage.has('fullName')) {
  username.value = LocalStorage.getItem('username');
  role.value = LocalStorage.getItem('role');
  firstName.value = LocalStorage.getItem('firstName');
  lastName.value = LocalStorage.getItem('lastName');
  email.value = LocalStorage.getItem('email');
  fullName.value = LocalStorage.getItem('fullName');
};



const getAllStudents = async () => {
  const fetchData = new FetchDataRequest<unknown>(searchKey.value, filter.value);
  await paginationUtil.value.initiate<unknown, MemberRecords>(
    studentStore.getAllStudents,
    fetchData,
  );
}

const goToIdentityVerificationPage = async () => {
  router.push('/cleverchap/identity-verification');
}



const getAllParents = async () => {
  const fetchData = new FetchDataRequest<unknown>(searchKey.value, filter.value);
  await paginationUtil.value.initiate<unknown, MemberRecords>(
    contributionStore.getAllParents,
    fetchData,
  );
}

const getAllDelegates = async () => {
  const fetchData = new FetchDataRequest<unknown>(searchKey.value, filter.value);
  await paginationUtil.value.initiate<unknown, MemberRecords>(
    donationStore.getAllDelegates,
    fetchData,
  );
}


const getAllStudentAttendance = async () => {
  const fetchData = new FetchDataRequest<unknown>(searchKey.value, filter.value);
  await paginationUtil.value.initiate<unknown, MemberRecords>(
    studentStore.getAllStudentAttendance,
    fetchData,
  );
}

const loadRecords = async () => {
  getAllParents(),
    getAllDelegates(),
    getAllStudents(),
    getAllStudentAttendance()
}


onMounted(() => {
  loadRecords()
});

</script>

<style scoped>
@import '../../css/hope-ui.css';
@import '../../css/custom.min.css';
@import '../../css/hope-ui.min.css';
@import '../../css/core/libs.min.css';
</style>
