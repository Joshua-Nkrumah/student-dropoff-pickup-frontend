<template>
  <main class="main-content">
    <BottomHeader>
      <template #actions>
      </template>
    </BottomHeader>
    <div style="margin-top: -4rem;" class="q-pa-lg">
      <div class="row">
        <div class="col-12 ">
          <my-search-box v-model="searchKey" :on-refresh="loadRecords" />
          <q-card class="card-shadow1 q-mt-lg" flat>
            <q-card-section>
              <q-tabs v-model="tab" dense class="text-grey " active-color="primary" indicator-color="primary"
                align="justify" narrow-indicator>
                <q-tab name="parents" label="Parents" />
                <q-tab name="delegates" label="Delegates" />
              </q-tabs>
              <q-separator />

              <q-tab-panels v-model="tab" animated class="q-mt-sm">
                <q-tab-panel name="parents">
                  <q-table title="Parents" flat :filter="searchKey" :loading="paginationUtil.loading"
                    v-model:pagination="paginationUtil.pagination" :rows="parentStore.listOfContributions?.records"
                    :columns="columns" row-key="id" padding id="form1">
                    <template v-slot:body-cell-ParentStatus="props">
                      <q-td key="ParentStatus" :props="props">
                        <q-badge v-if="props.row.parent.status === 'Active'" class="q-pl-md q-pr-md" label="Active" fill
                          color="green-8" style="height: 1.5rem;" />
                        <q-badge v-if="props.row.parent.status === 'Inactive'" class="q-pl-md q-pr-md" label="Inactive"
                          fill color="yellow-8" style="height: 1.5rem;" />
                        <q-badge v-if="props.row.parent.status === 'Deleted'" class="q-pl-md q-pr-md" label="Deleted" fill
                          color="red-7" style="height: 1.5rem;" />
                      </q-td>
                    </template>


                    <template v-slot:body-cell-Gender="props">
                      <q-td key="Gender" :props="props">
                        <div v-if="props.row.gender === 'male'" class="q-pl-md q-pr-md">Male</div>
                        <div v-if="props.row.gender === 'female'" class="q-pl-md q-pr-md">Female</div>
                      </q-td>
                    </template>

                    <template v-slot:body-cell-actions="props">
                      <q-td key="actions" :props="props" auto-width>
                        <div class="row wrap justify-between"></div>
                        <q-btn-dropdown color="grey-8" dense>
                          <q-list>
                            <q-item clickable @click="onshowPrintContributionDialog(props.row as MemberRecords)">
                              <q-item-section side>
                                <q-icon name="o_receipt_long" />
                              </q-item-section>
                              <q-item-section>
                                <q-item-label>Print Receipt</q-item-label>
                              </q-item-section>
                            </q-item>
                            <q-item clickable @click="onshowUpdateContributionDialog(props.row as MemberRecords)">
                              <q-item-section side>
                                <q-icon name="o_edit" />
                              </q-item-section>
                              <q-item-section>
                                <q-item-label>Update Parent</q-item-label>
                              </q-item-section>
                            </q-item>

                          </q-list>
                        </q-btn-dropdown>
                      </q-td>
                    </template>
                  </q-table>
                </q-tab-panel>

                <q-tab-panel name="delegates">
                  <q-table title="Delegates" flat :filter="searchKey" :loading="paginationUtil.loading"
                    v-model:pagination="paginationUtil.pagination" :rows="delegateStore.listOfDonations?.records"
                    :columns="delegateColumns" row-key="id" padding id="form1">
                    <template v-slot:body-cell-DelegateStatus="props">
                      <q-td key="DelegateStatus" :props="props">
                        <q-badge v-if="props.row.authorizedDelegate.status === 'Active'" class="q-pl-md q-pr-md"
                          label="Active" fill color="green-8" style="height: 1.5rem;" />
                        <q-badge v-if="props.row.authorizedDelegate.status === 'Inactive'" class="q-pl-md q-pr-md"
                          label="Inactive" fill color="yellow-8" style="height: 1.5rem;" />
                        <q-badge v-if="props.row.authorizedDelegate.status === 'Deleted'" class="q-pl-md q-pr-md"
                          label="Deleted" fill color="red-7" style="height: 1.5rem;" />
                      </q-td>
                    </template>


                    <template v-slot:body-cell-actions="props">
                      <q-td key="actions" :props="props" auto-width>
                        <div class="row wrap justify-between"></div>
                        <q-btn-dropdown color="grey-8" dense>
                          <q-list>
                            <q-item clickable @click="onshowPrintContributionDialog(props.row as MemberRecords)">
                              <q-item-section side>
                                <q-icon name="o_receipt_long" />
                              </q-item-section>
                              <q-item-section>
                                <q-item-label>Print Receipt</q-item-label>
                              </q-item-section>
                            </q-item>
                            <q-item clickable @click="onshowUpdateContributionDialog(props.row as MemberRecords)">
                              <q-item-section side>
                                <q-icon name="o_edit" />
                              </q-item-section>
                              <q-item-section>
                                <q-item-label>Update Delegate</q-item-label>
                              </q-item-section>
                            </q-item>

                          </q-list>
                        </q-btn-dropdown>
                      </q-td>
                    </template>
                  </q-table>
                </q-tab-panel>
              </q-tab-panels>
            </q-card-section>
          </q-card>


        </div>
        <div class="q-pt-lg">
        </div>
      </div>
    </div>
  </main>
  <!-- <q-dialog v-model="showContributionDialog" rounded style="width: 100% !important;">
    <q-card style="width: 900px; max-width: 100vw;">
      <q-toolbar>
        <q-avatar>
          <q-icon name="person_add_alt" color="blue-9" size="30px" v-if="isUpdate == false" />
          <q-icon name="edit" color="blue-9" size="30px" v-if="isUpdate == true" />
        </q-avatar>
        <q-toolbar-title color="blue-9" v-if="isUpdate == false"><span class="text-weight-bold">Add
            Contribution</span></q-toolbar-title>
        <q-toolbar-title color="blue-9" v-if="isUpdate == true"><span class="text-weight-bold">Update
            Contribution</span></q-toolbar-title>
        <q-btn flat round dense icon="close" v-close-popup />
      </q-toolbar>
      <q-card-section>
        <q-card class="card-shadow q-ml-xl q-mr-xl">
          <q-card-section style="margin-top: 0.4rem;">
            <q-item>
              <div class="row flex-center">
                <q-item-section class="col-12">
                  <q-item-label class="text-weight-bold" style="font-size: 1.5rem">
                    {{ selectedMemberPayload.firstName }} {{ selectedMemberPayload.middleName }} {{
                      selectedMemberPayload.lastName }}
                  </q-item-label>
                  <q-item-label caption lines="1" class="text-bold" style="font-size: 1rem">
                    {{ selectedMemberPayload.emailAddress }}, {{ selectedMemberPayload.phoneNumber }}
                  </q-item-label>
                </q-item-section>
              </div>
            </q-item>
          </q-card-section>
        </q-card>
        <div class="">
          <q-stepper v-model="step" vertical color="primary" animated flat>
            <q-step :name="1" title="Add a new contribution for the member above" :done="step > 1">
              <q-form @submit="onProcessUpdateContribution" @reset="onReset">
                <div class="row q-col-gutter-x-lg  ">
                  <div class="col-md-6">
                    <q-input v-model="contributionPayload.amount" label="Amount *" type="number" lazy-rules readonly />
                  </div>
                  <div class="col-md-6">
                    <q-select v-model="contributionPayload.contributionStatus" :options="contributionStatusOptions"
                      label="Contribution Status" lazy-rules transition-show="scale" transition-hide="scale"
                      behavior="default"
                      :rules="[(val: string | any[]) => (val && val.length > 0) || 'Select Contribution Status']">
                      <q-tooltip anchor="center middle" self="bottom left">Select the contribution status
                      </q-tooltip>
                    </q-select>
                  </div>
                  <div class="col-md-6">
                    <q-input v-model="contributionPayload.remarks" label="Remarks " lazy-rules
                      :rules="[val => val && val.length > 0 || 'Enter the remarks for the contribution']"
                      v-if="contributionPayload.contributionStatus === 'pending'" />
                    <q-input v-model="contributionPayload.remarks" label="Remarks " lazy-rules v-else />
                  </div>
                  <div class="col-md-6">
                    <q-select v-model="contributionPayload.description" :options="descriptionTypeOptions"
                      label="Description" lazy-rules transition-show="scale" transition-hide="scale" behavior="default"
                      :rules="[(val: string | any[]) => (val && val.length > 0) || 'Select contribution description']">
                      <q-tooltip anchor="center middle" self="bottom left">Select the contribution description
                      </q-tooltip>
                    </q-select>
                  </div>

                </div>
                <q-stepper-navigation>
                  <q-btn color="primary" label="Add Contribution" type="submit" :loading="loading"
                    v-if="isUpdate == false" class="q-mr-md" />
                  <q-btn color="primary" label="Update Contribution" :loading="loading" type="submit"
                    v-if="isUpdate == true" class="q-mr-md" />
                  <q-btn color="dark" label="Clear All" @click="onReset()" />
                </q-stepper-navigation>
              </q-form>
            </q-step>
          </q-stepper>
        </div>
      </q-card-section>
    </q-card>
  </q-dialog> -->
  <!-- <q-dialog v-model="showPrintContributionDialog" rounded style="width: 100% !important;">
    <q-card style="width: 900px; max-width: 100vw;">
      <q-toolbar>
        <q-avatar>
          <q-icon name="fa-solid fa-print" color="blue-9" size="30px" />
        </q-avatar>
        <q-toolbar-title color="blue-9" v-if="isUpdate == false"><span class="text-weight-bold">Print
            Receipt</span></q-toolbar-title>
        <q-btn flat round dense icon="close" v-close-popup />
      </q-toolbar>
      <q-card-section>
        <q-card class="card-shadow q-ml-xl q-mr-xl">
          <q-card-section style="margin-top: 0.4rem;" class="row justify-between">
            <q-item>
              <div class="row ">
                <q-item-section class="col-12">
                  <q-item-label class="text-weight-bold" style="font-size: 1.5rem">
                    {{ selectedMemberPayload.firstName }} {{ selectedMemberPayload.middleName }} {{
                      selectedMemberPayload.lastName }}
                  </q-item-label>
                  <q-item-label caption lines="1" class="text-bold" style="font-size: 1rem">
                    {{ selectedMemberPayload.emailAddress }}, {{ selectedMemberPayload.phoneNumber }}
                  </q-item-label>
                </q-item-section>
              </div>
            </q-item>
            <q-item>
              <q-btn icon="fa-solid fa-print" label="Print Receipt" size="18px" color="primary" text-color="white"
                class="text-bold" no-caps push @click="onPrintPage()" />
            </q-item>
          </q-card-section>
        </q-card>
        <div class="row q-col-gutter-x-lg" id="printReceipt">
          <div class="col-md-12 q-mb-lg">
            <q-card class="card-shadow main_container q-pa-xl " flat>
              <q-card-section class="text-subitle4 ">
                <div class="sub_container col" id="specific-part">
                  <div class="receipt_top ">
                    <div class="receipt_header row justify-between">
                      <div class="col">
                        <div>
                        </div>
                        <div class="q-mt-xs">
                          <span class="text-h6 text-bold"> Receipt</span>
                        </div>
                      </div>
                      <div class="col">
                        <div class="receipt_id text-right text-bold">
                          <span>Receipt Id: {{ selectedContributionPayload.receiptId }}</span>
                        </div>
                      </div>
                    </div>
                    <q-separator color="dark" size="0.4rem" inset class="q-mt-sm" />
                    <q-card class="receipt_content col card-shadow" flat>
                      <q-card-section>
                        <div class="row justify-between">
                          <div>Service Type: </div>
                          <div>Contribution</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Contributor's Name: </div>
                          <div>{{ selectedMemberPayload.firstName }} {{ selectedMemberPayload.middleName }}
                            {{ selectedMemberPayload.lastName }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Contributor's Email Address: </div>
                          <div>{{ selectedMemberPayload.emailAddress }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Contributor Phone Number: </div>
                          <div>{{ selectedMemberPayload.phoneNumber }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Contributor Location: </div>
                          <div>{{ selectedMemberPayload.location }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Total Amount (GH<span style="font-size: 18px;">¢</span>) </div>
                          <div>{{ selectedContributionPayload.amount }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Contribution Status</div>
                          <div>{{ selectedContributionPayload.contributionStatus }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Description</div>
                          <div>{{ selectedContributionPayload.description }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Contributor's Signature: </div>
                        </div>
                      </q-card-section>
                    </q-card>
                    <q-card class="receipt_footer card-shadow" flat>
                      <q-card-section class="row">
                        <div class="col text-left">
                          <div class="title">Branch</div>
                          <div class="content">OCC North Kaneshie</div>
                        </div>
                        <q-separator vertical size="0.2rem" color="dark" inset class="q-mr-lg" />
                        <div class="col text-center">
                          <div class="title">Served By</div>
                          <div class="content">{{ username }}</div>
                        </div>
                        <q-separator vertical size="0.2rem" color="dark" inset class="q-ml-lg q-mr-lg" />
                        <div class="col text-right">
                          <div class="title">Contribution Date</div>
                          <div class="content">{{ selectedContributionPayload.createdAt }}</div>
                        </div>
                      </q-card-section>
                    </q-card>
                  </div>
                  <div class="receipt_middle" style="height: 10.2px;">
                    <div class="divider" style="border: 2px black dashed; margin-top: 5px;">
                    </div>
                  </div>
                  <div class="receipt_bottom">
                    <div class="receipt_header row justify-between">
                      <div class="col">
                        <div>
                        </div>
                        <div class="q-mt-xs">
                          <span class="text-h6 text-bold"> Receipt</span>
                        </div>
                      </div>
                      <div class="col">
                        <div class="receipt_id text-right text-bold">
                          <span>Receipt Id: {{ selectedContributionPayload.receiptId }}</span>
                        </div>
                      </div>
                    </div>
                    <q-separator color="dark" size="0.4rem" inset class="q-mt-sm" />
                    <q-card class="receipt_content col card-shadow" flat>
                      <q-card-section>
                        <div class="row justify-between">
                          <div>Service Type: </div>
                          <div>Contribution</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Contributor's Name: </div>
                          <div>{{ selectedMemberPayload.firstName }} {{ selectedMemberPayload.middleName }}
                            {{ selectedMemberPayload.lastName }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Contributor's Email Address: </div>
                          <div>{{ selectedMemberPayload.emailAddress }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Contributor Phone Number: </div>
                          <div>{{ selectedMemberPayload.phoneNumber }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Contributor Location: </div>
                          <div>{{ selectedMemberPayload.location }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Total Amount (GH<span style="font-size: 18px;">¢</span>) </div>
                          <div>{{ selectedContributionPayload.amount }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Contribution Status</div>
                          <div>{{ selectedContributionPayload.contributionStatus }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Description</div>
                          <div>{{ selectedContributionPayload.description }}</div>
                        </div>
                        <q-separator />
                        <div class="row justify-between">
                          <div>Contributor's Signature: </div>
                        </div>
                      </q-card-section>
                    </q-card>
                    <q-card class="receipt_footer card-shadow" flat>
                      <q-card-section class="row">
                        <div class="col text-left">
                          <div class="title">Branch</div>
                          <div class="content">OCC North Kaneshie</div>
                        </div>
                        <q-separator vertical size="0.2rem" color="dark" inset class="q-mr-lg" />
                        <div class="col text-center">
                          <div class="title">Served By</div>
                          <div class="content">{{ username }}</div>
                        </div>
                        <q-separator vertical size="0.2rem" color="dark" inset class="q-ml-lg q-mr-lg" />
                        <div class="col text-right">
                          <div class="title">Contribution Date</div>
                          <div class="content">{{ selectedContributionPayload.createdAt }}</div>
                        </div>
                      </q-card-section>
                    </q-card>
                  </div>
                </div>
                <strong></strong>
              </q-card-section>
            </q-card>
          </div>
        </div>
      </q-card-section>
    </q-card>
  </q-dialog> -->
  <q-dialog v-model="confirmMemberDialog" persistent>
    <q-card>
      <q-card-section class="row items-center">
        <div class="col">
          <q-avatar icon="o_delete" color="primary" text-color="white" />
          <span class="q-ml-sm">Do you really want to mark this member as deleted?</span>
        </div>
      </q-card-section>
      <q-card-actions align="right">
        <q-btn flat label="Cancel" color="primary" v-close-popup />
        <q-btn flat label="Mark as Delete" color="primary" @click="onProcessSoftDeleteMember()" />
      </q-card-actions>
    </q-card>
  </q-dialog>

  <q-dialog v-model="confirmMailReceiptDialog" persistent>
    <q-card>
      <q-card-section class="row items-center">
        <div class="col">
          <q-avatar icon="o_forward_to_inbox" color="primary" text-color="white" />
          <span class="q-ml-sm">Do you really want to send this receipt as mail?</span>
        </div>
      </q-card-section>
      <q-card-actions align="right">
        <q-btn flat label="Cancel" color="primary" v-close-popup />
        <q-btn flat label="Send Receipt as Mail" color="primary" @click="onProcessSendContributionReceiptAsMail()"
          :loading="loading" />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script lang="ts" setup >
import { useMemberStore } from 'src/stores/student/student.store';
import BottomHeader from 'components/structure/BottomHeader.vue';
import { useContributionStore } from 'src/stores/contribution/contribution.store';
import MySearchBox from 'components/utils/MySearchBar.vue';
import { ref, onMounted } from 'vue';
import { LocalStorage, useQuasar } from 'quasar';
import AAStatusConstants from 'src/constants/aa-status.constants';
import PaginationUtil from 'src/utils/pagination.utils';
import FetchDataRequest from 'src/models/FetchDataRequest.model';
import { MemberRecords } from 'src/models/student/AllMembers.model';
import { useDonationStore } from 'src/stores/donation/donation.store';

// ------------------------------- GLOBAL DECLARATIONS --------------------------------- //
const $q = useQuasar();
const memberStore = useMemberStore();
const parentStore = useContributionStore();
const delegateStore = useDonationStore();
const paginationUtil = ref(new PaginationUtil());
const searchKey = ref('');
const confirmMemberDialog = ref(false);
const confirmMailReceiptDialog = ref(false);
const loading = ref(false);
const isUpdate = ref(false);
const filter = ref(null);
const memberID = ref('');
const showContributionDialog = ref(false);
const showPrintContributionDialog = ref(false);
const memberId = ref('');
const tab = ref('parents')


const username = <any>ref(null);

if (LocalStorage.has('username')) {
  username.value = LocalStorage.getItem('username');
};

// ------------------------------- REQUEST PAYLOAD --------------------------------- //
const contributionPayload = ref(
  {
    memberId: '',
    contributionId: '',
    amount: parseFloat(''),
    description: '',
    contributionStatus: '',
    createdBy: '',
    remarks: ''
  });

const singleContributionPayload = ref(
  {
    memberId: '',
    contributionId: ''
  });

const selectedContributionPayload = ref({
  memberId: '',
  contributionId: '',
  amount: parseFloat(''),
  description: '',
  contributionStatus: '',
  createdBy: '',
  remarks: '',
  createdAt: '',
  receiptId: ''
})

const selectedMemberPayload = ref(
  {
    firstName: 'Joshua',
    middleName: 'Kwaku',
    lastName: 'Nkrumah',
    emailAddress: 'joshua@gmail.com',
    phoneNumber: '0548068712',
    location: ''
  });


// ------------------------------- MEMBER METHODS --------------------------------- //








const onProcessSoftDeleteMember = async () => {
  loading.value = true;

  const result = await memberStore.softDeleteMember({
    memberID: memberID.value
  });
  loading.value = false;
  if (result.status == AAStatusConstants.SUCCESS) {
    confirmMemberDialog.value = false;
    $q.notify({
      color: 'green-8',
      textColor: 'white',
      icon: 'cloud_done',
      position: 'top-right',
      message: `${result.message}`,
    });
  } else {
    $q.notify({
      color: 'red-8',
      textColor: 'white',
      icon: 'close',
      position: 'top-right',
      message: `${result.message}`,
    });
  }
};

const onProcessSendContributionReceiptAsMail = async () => {
  loading.value = true;
  const result = await parentStore.sendContributionReceiptAsMail(singleContributionPayload.value);
  loading.value = false;
  if (result.status == AAStatusConstants.SUCCESS) {
    confirmMailReceiptDialog.value = false;
    $q.notify({
      color: 'green-8',
      textColor: 'white',
      icon: 'cloud_done',
      position: 'top-right',
      message: `${result.message}`,
    });
  } else {
    $q.notify({
      color: 'red-8',
      textColor: 'white',
      icon: 'close',
      position: 'top-right',
      message: `${result.message}`,
    });
  }
};

const loadRecords = async () => {
  getAllParents(),
    getAllDelegates()
}

const getAllParents = async () => {
  const fetchData = new FetchDataRequest<unknown>(searchKey.value, filter.value);
  await paginationUtil.value.initiate<unknown, MemberRecords>(
    parentStore.getAllParents,
    fetchData,
  );
}

const getAllDelegates = async () => {
  const fetchData = new FetchDataRequest<unknown>(searchKey.value, filter.value);
  await paginationUtil.value.initiate<unknown, MemberRecords>(
    delegateStore.getAllDelegates,
    fetchData,
  );
}




// ------------------------------- HELPER METHODS --------------------------------- //


const onshowUpdateContributionDialog = (row: any) => {
  isUpdate.value = true;
  showContributionDialog.value = true;
  selectedMemberPayload.value = {
    firstName: row.members.firstName,
    emailAddress: row.members.emailAddress,
    lastName: row.members.lastName,
    middleName: row.members.middleName,
    phoneNumber: row.members.phoneNumber,
    location: row.members.location,
  };
  contributionPayload.value = {
    memberId: row.contribution.memberId,
    contributionId: row.contribution.contributionId,
    amount: parseFloat(row.contribution.amount),
    description: row.contribution.description,
    contributionStatus: row.contribution.contributionStatus,
    createdBy: row.contribution.createdBy,
    remarks: row.contribution.remarks

  }
  memberId.value = row.members.memberId;
};

const onshowPrintContributionDialog = (row: any) => {
  showPrintContributionDialog.value = true;
  selectedMemberPayload.value = {
    firstName: row.members.firstName,
    emailAddress: row.members.emailAddress,
    lastName: row.members.lastName,
    middleName: row.members.middleName,
    phoneNumber: row.members.phoneNumber,
    location: row.members.location,
  };
  selectedContributionPayload.value = {
    memberId: row.contribution.memberId,
    contributionId: row.contribution.contributionId,
    amount: parseFloat(row.contribution.amount),
    description: row.contribution.description,
    contributionStatus: row.contribution.contributionStatus,
    createdBy: row.contribution.createdBy,
    remarks: row.contribution.remarks,
    createdAt: formatCustomDate(row.contribution.createdAt),
    receiptId: row.contribution.receiptId
  }
  memberId.value = row.members.memberId;
}







function formatCustomDate(dateString: string): string {
  // Parse the input date string into a Date object
  const inputDate = new Date(dateString);

  // Check if the inputDate is valid
  if (isNaN(inputDate.getTime())) {
    return 'Invalid Date';
  }

  // Get the day, month, year, hours, and minutes
  const day = inputDate.getDate();
  const monthNames = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul',
    'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  const month = monthNames[inputDate.getMonth()];
  const year = inputDate.getFullYear();
  const hours = inputDate.getHours();
  const minutes = inputDate.getMinutes();
  const ampm = hours >= 12 ? 'pm' : 'am';

  // Format the date string
  const formattedDate = `${day}th ${month}, ${year}, ${hours}:${minutes.toString().padStart(2, '0')} ${ampm}`;

  return formattedDate;
}

// ------------------------------- TABLE COLUMNS AND ROWS --------------------------------- //

const columns: any = ([
  { name: 'actions', align: 'center', label: 'Action' },
  {
    name: 'ParentName',
    required: true,
    label: 'Parent Full Name',
    align: 'left',
    field: (row: any) => {
      return row?.parent?.firstName + ' ' + row?.parent?.lastName;
    },
  },
  {
    name: 'Relation',
    required: true,
    label: 'Relationship to Child',
    align: 'left',
    field: (row: any) => {
      return row?.parent?.type;
    },
  },
  {
    name: 'StudentName',
    required: true,
    label: 'Student Full Name',
    align: 'left',
    field: (row: any) => {
      return row?.student?.firstName + ' ' + row?.student?.lastName;
    },
  },
  {
    name: 'EmailAddress',
    align: 'left',
    label: 'Email Address',
    field: (row: any) => {
      return row?.parent?.email;
    },
    required: true,
  },
  {
    name: 'Nationality',
    align: 'left',
    label: 'Nationality',
    field: (row: any) => {
      return row?.parent?.nationality;
    },
    required: true,
  },
  {
    name: 'Phone',
    align: 'left',
    label: 'Phone Number',
    field: (row: any) => {
      return row?.parent?.phone;
    },
    required: true,
  },
  {
    name: 'ParentStatus',
    align: 'left',
    label: 'Status',
    field: (row: any) => {
      return row?.parent?.status;
    },
    required: true,
  },
  {
    name: 'DateCreated', align: 'left', label: 'Date Created', field: (row: any) => {
      return formatCustomDate(row?.parent?.createdAt);
    }
  },
  {
    name: 'CreatedBy', label: 'Created By', align: 'left', field: (row: any) => {
      return row?.parent?.createdBy;
    },
  },


]);

const delegateColumns: any = ([
  { name: 'actions', align: 'center', label: 'Action' },
  {
    name: 'DelegateName',
    required: true,
    label: 'Delegate Full Name',
    align: 'left',
    field: (row: any) => {
      return row?.authorizedDelegate?.firstName + ' ' + row?.authorizedDelegate?.lastName;
    },
  },
  {
    name: 'Relation',
    required: true,
    label: 'Relationship to Child',
    align: 'left',
    field: (row: any) => {
      return row?.authorizedDelegate?.relationshipToChild;
    },
  },
  {
    name: 'StudentName',
    required: true,
    label: 'Student Full Name',
    align: 'left',
    field: (row: any) => {
      return row?.student?.firstName + ' ' + row?.student?.lastName;
    },
  },
  {
    name: 'EmailAddress',
    align: 'left',
    label: 'Email Address',
    field: (row: any) => {
      return row?.authorizedDelegate?.email;
    },
    required: true,
  },
  {
    name: 'Phone',
    align: 'left',
    label: 'Phone Number',
    field: (row: any) => {
      return row?.authorizedDelegate?.phone;
    },
    required: true,
  },
  {
    name: 'DelegateStatus',
    align: 'left',
    label: 'Status',
    field: (row: any) => {
      return row?.authorizedDelegate?.status;
    },
    required: true,
  },
  {
    name: 'DateCreated', align: 'left', label: 'Date Created', field: (row: any) => {
      return formatCustomDate(row?.authorizedDelegate?.createdAt);
    }
  },
  {
    name: 'CreatedBy', label: 'Created By', align: 'left', field: (row: any) => {
      return row?.authorizedDelegate?.createdBy;
    },
  },


]);

// ------------------------------- ON MOUNTED --------------------------------- //

onMounted(() => {
  loadRecords()
});

</script>

<style scoped></style>

src/stores/member/student.store
