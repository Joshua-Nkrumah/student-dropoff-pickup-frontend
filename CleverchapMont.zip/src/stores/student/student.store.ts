/* eslint-disable @typescript-eslint/no-explicit-any */
import { defineStore } from 'pinia';
import ResponseUtil from 'src/utils/response.utils';
import TokenModel from 'src/models/auth/Token.model';
import AuthConstants from 'src/constants/auth.constants';
import FetchDataResponse from 'src/models/FetchDataResponse.model';
import WelfareLogic from 'src/logic/cleverchap.logic';
import AAStatusConstants from 'src/constants/aa-status.constants';
import { MemberRecords } from 'src/models/student/AllMembers.model';
import { MemberYearSummaryData } from 'src/models/student/MemberYearSummary.model';
import { AttendanceRecord } from 'src/models/student/AllAttendance.model';

export const useMemberStore = defineStore('member', {
  state: () => ({
    /** @type {TokenModel} */
    token: new TokenModel(),

      /** @type {FetchDataResponse<MemberRecords>} */
      listOfMembers: new FetchDataResponse<MemberRecords>(),

       /** @type {FetchDataResponse<AttendanceRecord>} */
       listOfAttendance: new FetchDataResponse<AttendanceRecord>(),

      /** @type {FetchDataResponse<MemberYearSummaryData>} */
      listOfMembersSummary: new FetchDataResponse<MemberYearSummaryData>(),

 /** @type {AuthLogic} */
    logic: new WelfareLogic(),

    status: AuthConstants.LOGOUT,
  }),
  getters: {
    isAuthenticated: (state) => state.status === AuthConstants.LOGIN,
  },
  actions: {

    async createStudent(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.createStudent(payload);
        return ResponseUtil.minimal(response);
      });
    },


    async editStudent(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.editStudent(payload);
        return ResponseUtil.minimal(response);
      });
    },


    async softDeleteMember(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.softDeleteMember(payload);
        return ResponseUtil.minimal(response);
      });
    },

    async deleteMember(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.deleteMember(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
        }
        return ResponseUtil.minimal(response);
      });
    },

    async getMember(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getMember(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
        }
        return ResponseUtil.minimal(response);
      });
    },

    async getAllStudents(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getAllStudents(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          this.listOfMembers = response.data;
        }
        return ResponseUtil.minimal(response);
      });
    },

    async getAllStudentAttendance(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getAllStudentAttendance(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          this.listOfAttendance = response.data;
        }
        return ResponseUtil.minimal(response);
      });
    },


    async getAllMembersSummary(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getAllMembersSummary(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          this.listOfMembersSummary = response.data;
        }
        return ResponseUtil.minimal(response);
      });
    },


  },
});
