/* eslint-disable @typescript-eslint/no-explicit-any */
import { defineStore } from 'pinia';
import ResponseUtil from 'src/utils/response.utils';
import TokenModel from 'src/models/auth/Token.model';
import AuthConstants from 'src/constants/auth.constants';
import FetchDataResponse from 'src/models/FetchDataResponse.model';
import WelfareLogic from 'src/logic/cleverchap.logic';
import AAStatusConstants from 'src/constants/aa-status.constants';
import { VolunteerData } from 'src/models/volunteer/AllVolunteer.model';
import { VolunteerYearSummaryData } from 'src/models/volunteer/VolunteerYearSummary.model';
import VerificationResponseData from 'src/models/volunteer/InitiateVerify.model';

export const useVolunteerStore = defineStore('volunteer', {
  state: () => ({
    /** @type {TokenModel} */
    token: new TokenModel(),

      /** @type {FetchDataResponse<VolunteerData>} */
      listOfVolunteers: new FetchDataResponse<VolunteerData>(),


      /** @type {FetchDataResponse<VolunteerYearSummaryData>} */
      listOfVolunteerSummary: new FetchDataResponse<VolunteerYearSummaryData>(),

    // flexcubeUser: new FlexcubeUserData(),

    /** @type {VerificationResponseData} */
    intiateVerify: new VerificationResponseData(),

 /** @type {AuthLogic} */
    logic: new WelfareLogic(),

    status: AuthConstants.LOGOUT,
  }),
  getters: {
    isAuthenticated: (state) => state.status === AuthConstants.LOGIN,
  },
  actions: {



    async initiateVerification(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.initiateVerification(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          this.intiateVerify = response.data as VerificationResponseData;
        }
        return ResponseUtil.minimal(response);
      });
    },


    async processVerification(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.processVerification(payload);

        return ResponseUtil.minimal(response);
      });
    },

    async softDeleteVolunteer(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.softDeleteVolunteer(payload);
        return ResponseUtil.minimal(response);
      });
    },

    async deleteVolunteer(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.deleteVolunteer(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
        }
        return ResponseUtil.minimal(response);
      });
    },

    async getVolunteer(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getVolunteer(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
        }
        return ResponseUtil.minimal(response);
      });
    },

    async getAllVolunteers(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getAllVolunteers(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          this.listOfVolunteers = response.data;
        }
        return ResponseUtil.minimal(response);
      });
    },

    async getAllVolunteerSummary(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getAllVolunteerSummary(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          this.listOfVolunteerSummary = response.data;
        }
        return ResponseUtil.minimal(response);
      });
    },

  },
});
