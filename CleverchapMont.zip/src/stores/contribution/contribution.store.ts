/* eslint-disable @typescript-eslint/no-explicit-any */
import { defineStore } from 'pinia';
import ResponseUtil from 'src/utils/response.utils';
import TokenModel from 'src/models/auth/Token.model';
import AuthConstants from 'src/constants/auth.constants';
import FetchDataResponse from 'src/models/FetchDataResponse.model';
import WelfareLogic from 'src/logic/cleverchap.logic';
import AAStatusConstants from 'src/constants/aa-status.constants';
import { MemberData } from 'src/models/student/AllMembers.model';
import { ContributionRecord } from 'src/models/contribution/AllContribution.model';
import { ContributionYearSummaryData } from 'src/models/contribution/ContributionYearSummary.model';
import { TotalContributionAmountData } from 'src/models/contribution/TotalAmountMonthYear.model';

export const useContributionStore = defineStore('contribution', {
  state: () => ({
    /** @type {TokenModel} */
    token: new TokenModel(),

      /** @type {FetchDataResponse<MemberData>} */
      listOfMembers: new FetchDataResponse<MemberData>(),

      /** @type {FetchDataResponse<ContributionData>} */
      listOfContributions: new FetchDataResponse<ContributionRecord>(),

      /** @type {FetchDataResponse<ContributionYearSummaryData>} */
      listOfContributionSummary: new FetchDataResponse<ContributionYearSummaryData>(),

       /** @type {FetchDataResponse<TotalContributionAmountData>} */
       listOfContributionYearMonthTotal: new FetchDataResponse<TotalContributionAmountData>(),


 /** @type {AuthLogic} */
    logic: new WelfareLogic(),

    status: AuthConstants.LOGOUT,
  }),
  getters: {
    isAuthenticated: (state) => state.status === AuthConstants.LOGIN,
  },
  actions: {

    // async receivableCountries(payload: any) {
    //   return ResponseUtil.handleAxiosCall(async () => {
    //     const response = await this.logic.getReceivableCountries(payload);
    //     if (response.status === AAStatusConstants.SUCCESS && response.data) {
    //       this.listOfReceivableCountries = response.data as CountryData;
    //     }
    //     return ResponseUtil.minimal(response);
    //   });
    // },

    async createParent(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.createParent(payload);
        // if (response.status === AAStatusConstants.SUCCESS && response.data) {
        //   this.AddPayment = response.data as APData;
        // }
        return ResponseUtil.minimal(response);
      });
    },


    async editParent(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.editParent(payload);
        return ResponseUtil.minimal(response);
      });
    },


    async softDeleteContribution(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.softDeleteContribution(payload);

        return ResponseUtil.minimal(response);
      });
    },

    async deleteContribution(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.deleteContribution(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          // this.AddPayment = response.data as APData;
        }
        return ResponseUtil.minimal(response);
      });
    },

    async getContribution(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getContribution(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          // this.AddPayment = response.data as APData;
        }
        return ResponseUtil.minimal(response);
      });
    },

    async getAllParents(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getAllParents(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          this.listOfContributions = response.data;
        }
        return ResponseUtil.minimal(response);
      });
    },


    async getAllContributionSummary(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getAllContributionSummary(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          this.listOfContributionSummary = response.data;
        }
        return ResponseUtil.minimal(response);
      });
    },

    async getAllContributionMonthYearTotal(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getAllContributionMonthYearTotal(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          this.listOfContributionYearMonthTotal = response.data;
        }
        return ResponseUtil.minimal(response);
      });
    },

    async sendContributionReceiptAsMail(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.sendContributionReceiptAsMail(payload);
        // if (response.status === AAStatusConstants.SUCCESS && response.data) {
        // }
        return ResponseUtil.minimal(response);
      });
    },
  },
});
