/* eslint-disable @typescript-eslint/no-explicit-any */
import { defineStore } from 'pinia';
import Response from 'src/models/response.model';
import ResponseUtil from 'src/utils/response.utils';
import TokenModel from 'src/models/auth/Token.model';
import AuthLogic from 'src/logic/auth.logic';
import AuthConstants from 'src/constants/auth.constants';
import StatusConstants from 'src/constants/status.constants';
import { cmApi } from 'src/boot/axios';
import { LocalStorage } from 'quasar';
import { User, UserResource } from 'src/models/auth/AssignedUserResource.model';

export const useAuthStore = defineStore('auth', {
  state: () => ({
    /** @type {TokenModel} */
    token: new TokenModel(),

    /** @type {AuthLogic} */
    authLogin: new AuthLogic(),

    /** @type {UserResource} */
    userInfo: new UserResource(),

    /** @type {User} */
    listOfUserInfo: new User(),
    u: '',
    p: '',

    status: AuthConstants.LOGOUT,
  }),
  getters: {
    isAuthenticated: (state) => state.status === AuthConstants.LOGIN,
  },
  actions: {
    async login(model: any): Promise<Response<void>> {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.authLogin.login(model);
        if (response.status === StatusConstants.SUCCESS) {
          this.status = AuthConstants.LOGIN;

          LocalStorage.set('result', JSON.stringify(response.data));
          const result = JSON.parse(LocalStorage.getItem('result') ?? '{}');

          this.token.username = result?.username || '';
          this.token.accessToken = result?.accessToken || '';

          this.userInfo = result?.userResource;
          LocalStorage.set('isAuthenticated', this.isAuthenticated);
          LocalStorage.set('username', this.token.username);
          LocalStorage.set('email', this.userInfo);
          LocalStorage.set('firstName', this.userInfo.firstName);
          LocalStorage.set('lastName', this.userInfo.lastName);
          LocalStorage.set('fullName', this.userInfo.fullName);
          LocalStorage.set('phoneNumber', this.userInfo.phoneNumber);
          LocalStorage.set('role', this.userInfo.role);

          cmApi.defaults.headers.common[
            'Authorization'
          ] = `Bearer ${result?.accessToken}`;
        }

        return ResponseUtil.minimal(response);
      });
    },

    async remainInside(): Promise<void> {
      const result = JSON.parse(LocalStorage.getItem('result') ?? '{}');

      LocalStorage.set(
        'isAuthenticated',
        LocalStorage.getItem('isAuthenticated')
      );

      cmApi.defaults.headers.common[
        'Authorization'
      ] = `Bearer ${result?.accessToken}`;

      this.status = AuthConstants.LOGIN;
    },

    logout(): void {
      this.token = new TokenModel();
      this.authLogin = new AuthLogic();
      this.status = AuthConstants.LOGOUT;
      LocalStorage.remove('username');
      LocalStorage.remove('result');
      LocalStorage.remove('isAuthenticated');
    },

    setIsAuthenticated(): void {
      this.status = AuthConstants.LOGIN;
    },

    async refreshToken(): Promise<Response<void>> {
      return ResponseUtil.handleAxiosCall(async () => {
        if (this.status !== AuthConstants.LOGIN) {
          return new Response(
            StatusConstants.FAILED,
            'Not authenticated',
            null
          );
        }
        const response = await this.authLogin.refreshToken();

        return ResponseUtil.minimal(response);
      });
    },
  },
});
