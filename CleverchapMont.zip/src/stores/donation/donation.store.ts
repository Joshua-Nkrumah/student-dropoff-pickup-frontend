/* eslint-disable @typescript-eslint/no-explicit-any */
import { defineStore } from 'pinia';
import ResponseUtil from 'src/utils/response.utils';
import TokenModel from 'src/models/auth/Token.model';
import AuthConstants from 'src/constants/auth.constants';
import FetchDataResponse from 'src/models/FetchDataResponse.model';
import WelfareLogic from 'src/logic/cleverchap.logic';
import AAStatusConstants from 'src/constants/aa-status.constants';
import { MemberData } from 'src/models/student/AllMembers.model';
import { DonationYearSummaryData } from 'src/models/donation/DonationYearSummary.model';
import { TotalDonationAmountData } from 'src/models/donation/TotalAmountMonthYear.model';
import { DelegateRecord } from 'src/models/donation/AllDonation.model';

export const useDonationStore = defineStore('donation', {
  state: () => ({
    /** @type {TokenModel} */
    token: new TokenModel(),

      /** @type {FetchDataResponse<MemberData>} */
      listOfMembers: new FetchDataResponse<MemberData>(),

      /** @type {FetchDataResponse<DonationData>} */
      listOfDonations: new FetchDataResponse<DelegateRecord>(),

      /** @type {FetchDataResponse<DonationYearSummaryData>} */
      listOfDonationSummary: new FetchDataResponse<DonationYearSummaryData>(),

     /** @type {FetchDataResponse<TotalDonationAmountData>} */
     listOfDonationYearMonthTotal: new FetchDataResponse<TotalDonationAmountData>(),

 /** @type {AuthLogic} */
    logic: new WelfareLogic(),

    status: AuthConstants.LOGOUT,
  }),
  getters: {
    isAuthenticated: (state) => state.status === AuthConstants.LOGIN,
  },
  actions: {

    async createDelegate(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.createDelegate(payload);
        return ResponseUtil.minimal(response);
      });
    },


    async editDelegate(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.editDelegate(payload);
        return ResponseUtil.minimal(response);
      });
    },


    async softDeleteDonation(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.softDeleteDonation(payload);
        return ResponseUtil.minimal(response);
      });
    },

    async deleteDonation(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.deleteDonation(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
        }
        return ResponseUtil.minimal(response);
      });
    },

    async getDonation(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getDonation(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
        }
        return ResponseUtil.minimal(response);
      });
    },

    async getAllDelegates(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getAllDelegates(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          this.listOfDonations = response.data;
        }
        return ResponseUtil.minimal(response);
      });
    },


    async getAllDonationSummary(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getAllDonationSummary(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          this.listOfDonationSummary = response.data;
        }
        return ResponseUtil.minimal(response);
      });
    },

    async getAllDonationMonthYearTotal(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.getAllDonationMonthYearTotal(payload);
        if (response.status === AAStatusConstants.SUCCESS && response.data) {
          this.listOfDonationYearMonthTotal = response.data;
        }
        return ResponseUtil.minimal(response);
      });
    },

    async sendDonationReceiptAsMail(payload: any) {
      return ResponseUtil.handleAxiosCall(async () => {
        const response = await this.logic.sendDonationReceiptAsMail(payload);
        // if (response.status === AAStatusConstants.SUCCESS && response.data) {
        //   this.listOfDonationYearMonthTotal = response.data;
        // }
        return ResponseUtil.minimal(response);
      });
    },
  },
});
