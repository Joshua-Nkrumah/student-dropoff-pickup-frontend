<template>
  <router-view />
</template>

<script setup lang="ts">
// import { ref, watchEffect, onBeforeUnmount } from "vue";

// const useIdleDetection = async (logoutCallback: () => void,
//   timeoutDuration = 30 * 60 * 1000) => {
//   const lastInteraction = ref<number>(Date.now());

//   function resetTimer() {
//     lastInteraction.value = Date.now();
//   }

//   function checkIdle() {
//     const currentTime = Date.now();
//     const elapsedTime = currentTime - lastInteraction.value;

//     if (elapsedTime >= timeoutDuration) {
//       logoutCallback();
//     }
//   }

//   const interval = setInterval(checkIdle, 1000); // Check every second

//   onBeforeUnmount(() => {
//     clearInterval(interval);
//   });

//   return {
//     resetTimer
//   };
// }

</script>
