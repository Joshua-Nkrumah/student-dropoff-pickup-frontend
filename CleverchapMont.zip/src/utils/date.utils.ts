import { date } from 'quasar';
import StringUtil from './string.util';

export default class DateUtil {
  // static getShortDate(dateInput: Date) {
  //   const timeStamp = Date.now();
  //   return date.formatDate(timeStamp, 'YYYY/MM/DD');
  // }

  static getTodayShortDate(): string {
    const timeStamp = Date.now();
    return date.formatDate(timeStamp, 'YYYY/MM/DD');
  }

  static getTodayIsoDate(): string {
    const timeStamp = Date.now();
    return date.formatDate(timeStamp, 'YYYY-MM-DD');
    // const d = new Date("2015-03-25");
  }

  static getIsoDate(dateStr: string): string {
    return date.formatDate(dateStr, 'YYYY-MM-DD');
    // const d = new Date("2015-03-25");
  }

  static getDotNetCompactibleDate(dateStr: string | null): string | null {
    if (dateStr) {
      const date = new Date(dateStr);
      const year = StringUtil.padLeft(date.getFullYear().toString(), '0', 4);
      const month = StringUtil.padLeft(
        (date.getMonth() + 1).toString(),
        '0',
        2
      );
      const day = StringUtil.padLeft(date.getDate().toString(), '0', 2);

      return `${year}-${month}-${day}`;
    }
    return null;
  }
}
