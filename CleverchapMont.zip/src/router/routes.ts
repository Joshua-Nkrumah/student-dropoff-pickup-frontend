import { RouteRecordRaw } from 'vue-router';

const routes: RouteRecordRaw[] = [
  {
    path: '/',
    redirect: '/auth/login',
  },
  {
    path: '/auth',
    component: () => import('layouts/AuthLayout.vue'),
    children: [
      {
        path: 'login',
        name: 'login',
        component: () => import('pages/auth/LoginPage.vue'),
      },
      {
        path: 'forgot-password',
        name: 'forgotpassword',
        component: () => import('pages/auth/ForgotPasswordPage.vue'),
      },
    ],
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: () => import('layouts/AppLayout.vue'),
  },
  {
    path: '/cleverchap',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      {
        path: 'identity-verification',
        component: () => import('src/pages/app/CleverChapSecurityPage.vue'),
      },
      {
        path: 'students',
        component: () => import('src/pages/app/StudentManagerPage.vue'),
      },
      {
        path: 'parents',
        component: () => import('src/pages/app/ParentManagerPage.vue'),
      }
    ],
  },
  {
    path: '/logout',
    name: 'logout',
    component: () => import('src/pages/auth/LogoutPage.vue'),
  },
  // Always leave this as last one,
  // but you can also remove it
  {
    path: '/:catchAll(.*)*',
    component: () => import('pages/ErrorNotFound.vue'),
  },
];
export default routes;
