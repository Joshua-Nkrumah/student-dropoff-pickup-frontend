export default class ShapeConstants {
  public static readonly ROUNDED = 'rounded';
  public static readonly ROUND = 'round';
  public static readonly SQUARE = 'square';
}
