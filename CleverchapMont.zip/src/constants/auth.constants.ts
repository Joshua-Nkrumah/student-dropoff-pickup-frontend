export default class AuthConstants {
  public static readonly LOGIN = 'login';
  public static readonly LOGOUT = 'logout';
}
