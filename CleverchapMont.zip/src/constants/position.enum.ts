export enum Position {
  top,
  left,
  right,
  bottom,
}
