export default class RoleConstants {
  public static readonly ADMIN = 'admin';
  public static readonly REPORTER = 'reporter';
  public static readonly DEVELOPER = 'developer';
}
