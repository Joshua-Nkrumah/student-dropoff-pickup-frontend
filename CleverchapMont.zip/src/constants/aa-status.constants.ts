export default class AAStatusConstants {
  public static readonly ACTIVE = 'active';
  public static readonly SUCCESS = '00';
  public static readonly PENDING = 'pending';
  public static readonly FAILED = '01';
  public static readonly REJECTED = 'rejected';
  public static readonly PROCESSING = 'processing';
  public static readonly APPROVED = 'approved';
  public static readonly UNAUTHORIZED = 'unauthorized';
  public static readonly TELLERSOURCEACCOUNT = '100001005';
}
