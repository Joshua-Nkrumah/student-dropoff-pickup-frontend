import { AssignedUserResource } from './../models/auth/AssignedUserResource.model';
import Response from 'src/models/response.model';
import { cmApiPublic } from 'src/boot/axios';
import TokenModel from 'src/models/auth/Token.model';
import LoginRequestModel from 'src/models/auth/LoginRequest.model';

export default class AuthLogic {


  public async login(
    model: LoginRequestModel
  ): Promise<Response<AssignedUserResource>> {
    const response = await cmApiPublic.post('/auth/login', model);
    const result = response.data;

    return new Response<AssignedUserResource>(
      result.status,
      result.message,
      result.data
    );
  }

  public async logout(): Promise<Response<void>> {
    const response = await cmApiPublic.post('/auth/logout');
    const result = response.data;
    return new Response<void>(result.status, result.message, null);
  }

  public async refreshToken(): Promise<Response<TokenModel>> {
    const response = await cmApiPublic.get('/auth/refresh-token');
    const result = response.data;
    return new Response<TokenModel>(result.status, result.message, result.data);
  }
}
