
import FetchDataResponse from 'src/models/FetchDataResponse.model';
import Response from 'src/models/response.model';
import { cmApiPublic } from 'src/boot/axios';

export default class WelfareLogic {
  public async createStudent(payload: unknown) {
    const response = await cmApiPublic.post(
      'student/create-student',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async editStudent(payload: unknown) {
    const response = await cmApiPublic.post(
      'student/update-student',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async softDeleteMember(payload: unknown) {
    const response = await cmApiPublic.post(
      'student/soft-delete-student',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async deleteMember(payload: unknown) {
    const response = await cmApiPublic.post(
      'student/delete-student',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getMember(payload: unknown) {
    const response = await cmApiPublic.post(
      'student/get-student',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getAllStudents(payload: unknown) {
    const response = await cmApiPublic.post(
      'student/get-all-students',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getAllStudentAttendance(payload: unknown) {
    const response = await cmApiPublic.post(
      'attendance/get-all-attendances',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getAllStudentAttendanceSummary(payload: unknown) {
    const response = await cmApiPublic.post(
      'attendance/year-summary',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getAllMembersSummary(payload: unknown) {
    const response = await cmApiPublic.post(
      'student/year-summary',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }


  public async createParent(payload: unknown) {
    const response = await cmApiPublic.post(
      'parent/create-parent',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async editParent(payload: unknown) {
    const response = await cmApiPublic.post(
      'parent/update-parent',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async softDeleteContribution(payload: unknown) {
    const response = await cmApiPublic.post(
      'contribution/soft-delete-contribution',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async deleteContribution(payload: unknown) {
    const response = await cmApiPublic.post(
      'contribution/delete-contribution',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getContribution(payload: unknown) {
    const response = await cmApiPublic.post(
      'contribution/get-contribution',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getAllParents(payload: unknown) {
    const response = await cmApiPublic.post(
      'parent/get-all-parents',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }



  public async getAllContributionSummary(payload: unknown) {
    const response = await cmApiPublic.post(
      'contribution/year-summary',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getAllContributionMonthYearTotal(payload: unknown) {
    const response = await cmApiPublic.post(
      'contribution/total-amount-per-month-year',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async sendContributionReceiptAsMail(payload: unknown) {
    const response = await cmApiPublic.post(
      'contribution/send-receipt-mail',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }








  ////////////////////////////////////////////////////////////////

  public async createDelegate(payload: unknown) {
    const response = await cmApiPublic.post(
      'delegate/create-delegate',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async editDelegate(payload: unknown) {
    const response = await cmApiPublic.post(
      '"delegate/update-delegate',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async softDeleteDonation(payload: unknown) {
    const response = await cmApiPublic.post(
      'donation/soft-delete-donation',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async deleteDonation(payload: unknown) {
    const response = await cmApiPublic.post(
      'contribution/delete-donation',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getDonation(payload: unknown) {
    const response = await cmApiPublic.post(
      'donation/get-donation',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getAllDelegates(payload: unknown) {
    const response = await cmApiPublic.post(
      'delegate/get-all-delegates',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }


  public async getAllDonationSummary(payload: unknown) {
    const response = await cmApiPublic.post(
      'donation/year-summary',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getAllDonationMonthYearTotal(payload: unknown) {
    const response = await cmApiPublic.post(
      'donation/total-amount-per-month-year',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async sendDonationReceiptAsMail(payload: unknown) {
    const response = await cmApiPublic.post(
      'donation/send-receipt-mail',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }


  ////////////////////////////////////////////////////////////////

  public async initiateVerification(payload: unknown) {
    const response = await cmApiPublic.post(
      'verification/generate-otp',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async processVerification(payload: unknown) {
    const response = await cmApiPublic.post(
      'verification/verify-otp',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async softDeleteVolunteer(payload: unknown) {
    const response = await cmApiPublic.post(
      'volunteer/soft-delete-volunteer',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async deleteVolunteer(payload: unknown) {
    const response = await cmApiPublic.post(
      'volunteer/delete-volunteer',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getVolunteer(payload: unknown) {
    const response = await cmApiPublic.post(
      'volunteer/get-volunteer',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getAllVolunteers(payload: unknown) {
    const response = await cmApiPublic.post(
      'volunteer/get-all-volunteers',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }

  public async getAllVolunteerSummary(payload: unknown) {
    const response = await cmApiPublic.post(
      'volunteer/year-summary',
      payload
    );
    const result = response.data;
    return new Response(
      result.status,
      result.message,
      result.data
    );
  }


}
