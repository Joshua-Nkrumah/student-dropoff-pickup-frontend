import Response from 'src/models/response.model';
import { omegaCommunityApi } from 'src/boot/axios';
import { AllUsers, Users } from 'src/models/user/all_users.model';
import { UserRoles, UserRole } from 'src/models/user/user_roles.model';
import NewApp from 'src/models/user/new_item_response.model';
import FetchDataResponse from 'src/models/FetchDataResponse.model';

export default class UserLogic {

  public async getAllUsers(payload: unknown) {
    const { data: roleData } = await omegaCommunityApi.post<AllUsers>(
      '/user/all-users',
      payload
    );


    const { status, message, data } = roleData;

    return new Response<Users[]>(String(status), message, data);
  }


}
