<template>
  <!-- Left Side -->
  <div class="col-md-12 col-lg-12">
    <div class="row">
      <div class="col-md-12">
        <q-card bordered class="my-card shadow-1 card text-dark" style="height: 11rem; color: #333;">
          <!-- <q-img src="../../assets//images/occ/brand-shape1.svg">
            <div class="absolute-full text-subtitle2 flex flex-center">
              <q-card-section horizontal>
                <q-card-section class="q-pt-xs col-10">
                  <div class="text-h4 q-mt-sm text-bold"></div>
                  <div class="text-caption text-dark ">
                    <div class="text-h6 text-semibold">Yearly Contribution</div>
                    <div class="text-h6 text-semi-bold q-mt-md">
                      {{ currentYear }}
                    </div>
                  </div>
                </q-card-section>
                <q-card-section class="col-2  flex-center">
                  <div class="text-h6 text-semi-bold" style="margin-left: -1rem; margin-top: 4rem;">
                    <span></span>
                    <q-icon class="rounded-borders q-mt-md" name="fa-solid fa-hand-holding-dollar" size="2.8rem" />
                  </div>
                </q-card-section>
              </q-card-section>
            </div>
          </q-img> -->
          <q-table :filter="searchKey" :loading="paginationUtil.loading" flat
            v-model:pagination="paginationUtil.pagination" :rows="studentStore.listOfAttendance.records"
            :columns="columns" row-key="requestId" padding>
            <template v-slot:body-cell-StudentName="props">
              <q-td key="StudentName" :props="props">
                <q-badge fill class="primary-color" style="height: 1.5rem;">{{
                  attendanceStudent(props.row?.studentId)
                }}</q-badge>
              </q-td>
            </template>
            <template v-slot:body-cell-ActivityType="props">
              <q-td key="ActivityType" :props="props">
                <q-badge v-if="props.row.activityType === 'Drop-Off'" outline color="positive" label="Drop-Off" />
                <q-badge v-if="props.row.activityType === 'Pick-Up'" outline color="blue-8" label="Pick-Up" />
              </q-td>
            </template>
            <template v-slot:body-cell-Status="props">
              <q-td key="Status" :props="props">
                <q-badge v-if="props.row.status === 'Verified'" fill color="positive" label="Successful" />
              </q-td>
            </template>
            <template v-slot:body-cell-actions="props">
              <q-td key="actions" :props="props" auto-width>
                <div class="row wrap justify-between"></div>
                <q-btn-dropdown color="grey-8" dense>
                  <q-list>
                    <q-separator />
                  </q-list>
                </q-btn-dropdown>
              </q-td>
            </template>
            <template v-slot:top-left>
              <div class="text-h5">Attendance</div>
            </template>
          </q-table>
        </q-card>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useAuthStore } from 'src/stores/auth/auth-store';
import { useMemberStore } from 'src/stores/student/student.store';
import { useContributionStore } from 'src/stores/contribution/contribution.store';
import { useDonationStore } from 'src/stores/donation/donation.store';
import BottomHeader from 'components/structure/BottomHeader.vue';
import MySearchBox from 'components/utils/MySearchBar.vue';
import { useRouter } from 'vue-router';
import { ref, onMounted, watch, computed, Ref } from 'vue';
import { LocalStorage, useQuasar } from 'quasar';
import AAStatusConstants from 'src/constants/aa-status.constants';
import PaginationUtil from 'src/utils/pagination.utils';
import FetchDataRequest from 'src/models/FetchDataRequest.model';
import { useRoute } from 'vue-router';
import { MemberRecords } from 'src/models/student/AllMembers.model';
import { ContributionRecord } from 'src/models/contribution/AllContribution.model';
import { useVolunteerStore } from 'src/stores/verification/verification.store';



const $q = useQuasar();
const router = useRouter();
const store = useAuthStore();
const studentStore = useMemberStore();
const parentStore = useContributionStore();
const delegateStore = useDonationStore();
const currentYear = new Date().getFullYear();
const date = ref(null);
const paginationUtil = ref(new PaginationUtil());

const searchKey = ref('');
const filter = ref(null);

function attendanceStudent(studentId: string): string | null {
  const listOfStudents = studentStore?.listOfMembers?.records;

  if (!listOfStudents) {
    return null; // or handle the case when listOfStudents is undefined or null
  }
  var result = listOfStudents.filter((record) => record.studentId === studentId)[0];
  var fullName = result?.firstName + ' ' + result?.lastName + ' - ' + result?.studentNumber
  return fullName;
}

function attendanceParent(parentId: string): string | null {
  const listofParents = parentStore?.listOfContributions?.records;

  if (listofParents == null || listofParents.length === 0) {
    return null; // or handle the case when listofParents is undefined or empty
  }

  const result = listofParents.find((record) => record.parent?.parentId === parentId);

  if (result == null) {
    return 'NA'; // or handle the case when the parent with parentId is not found
  }

  const fullName = `${result.parent?.firstName ?? ''} ${result.parent?.lastName ?? ''} - ${result.parent?.type ?? ''}`;

  return fullName.trim() || 'NA'; // trim to handle cases where parts of the name or type might be undefined or null
}


function attendanceDelegate(delegateId: string): string | null {
  const listOfDelegates = delegateStore?.listOfDonations?.records;

  if (listOfDelegates == null || listOfDelegates.length === 0) {
    return 'Joshua'; // or handle the case when listOfDelegates is undefined or empty
  }

  const result = listOfDelegates.find((record) => record.authorizedDelegate?.delegateId === delegateId);

  if (result == null) {
    return 'NA'; // or handle the case when the delegate with delegateId is not found
  }

  const fullName = `${result.authorizedDelegate?.firstName ?? ''} ${result.authorizedDelegate?.lastName ?? ''} - ${result.authorizedDelegate?.relationshipToChild ?? ''}`;

  return fullName.trim() || 'NA'; // trim to handle cases where parts of the name or relationship might be undefined or null
}








function formatCustomDate(dateString: string): string {
  // Parse the input date string into a Date object
  const inputDate = new Date(dateString);

  // Check if the inputDate is valid
  if (isNaN(inputDate.getTime())) {
    return 'Invalid Date';
  }

  // Get the day, month, year, hours, and minutes
  const day = inputDate.getDate();
  const monthNames = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul',
    'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  const month = monthNames[inputDate.getMonth()];
  const year = inputDate.getFullYear();
  const hours = inputDate.getHours();
  const minutes = inputDate.getMinutes();
  const ampm = hours >= 12 ? 'pm' : 'am';

  // Format the date string
  const formattedDate = `${day}th ${month}, ${year}, ${hours}:${minutes.toString().padStart(2, '0')} ${ampm}`;

  return formattedDate;
}


// ------------------------------- TABLE COLUMNS AND ROWS --------------------------------- //

const getAllStudents = async () => {
  const fetchData = new FetchDataRequest<unknown>(searchKey.value, filter.value);
  await paginationUtil.value.initiate<unknown, MemberRecords>(
    studentStore.getAllStudents,
    fetchData,
  );
}

const getAllStudentAttendance = async () => {
  const fetchData = new FetchDataRequest<unknown>(searchKey.value, filter.value);
  await paginationUtil.value.initiate<unknown, MemberRecords>(
    studentStore.getAllStudentAttendance,
    fetchData,
  );
}

const columns: any = ([
  { name: 'actions', align: 'center', label: 'Action' },
  {
    name: 'StudentName',
    required: true,
    label: 'Student',
    align: 'center',
    field: (row: any) => {
      return attendanceStudent(row?.studentId);
    }
  },
  {
    name: 'ParentName',
    required: true,
    label: 'Parent',
    align: 'center',
    field: (row: any) => {
      return attendanceParent(row?.parentId);
    }
  },
  {
    name: 'DelegateName',
    required: true,
    label: 'Delegate',
    align: 'center',
    field: (row: any) => {
      return attendanceDelegate(row?.delegateId);
    }
  },
  {
    name: 'Relation',
    required: true,
    label: 'Relation To Child',
    align: 'center',
    field: (row: any) => {
      return attendanceDelegate(row?.delegateId);
    }
  },
  { name: 'Status', label: 'Verification Status', align: 'center', field: 'status' },
  {
    name: 'AuthorizedTimestamp', label: 'Authorized Timestamp', align: 'left', field: (row: any) => {
      return formatCustomDate(row?.authorizedDateTime);
    }
  },
  { name: 'ActivityType', align: 'left', label: 'Activity Type', field: 'activityType' },
  {
    name: 'DateCreated', align: 'left', label: 'Date Created', field: (row: any) => {
      return formatCustomDate(row?.createdAt);
    }
  },

]);

const loadRecords = async () => {
  getAllStudents(),
    getAllStudentAttendance()
}


onMounted(() => {
  loadRecords()
});

</script>

<style scoped>
@import '../../css/hope-ui.css';
@import '../../css/custom.min.css';
@import '../../css/hope-ui.min.css';
@import '../../css/core/libs.min.css';

.no_border_radius {
  border-radius: 0px !important;
}

.text-white {
  color: #ffffff !important;
  /* background-color: #ffe600; */
}

.q-carousel {
  background-color: transparent;
  /* Set the background color */
  border-radius: 4px;
  /* Optional: Add rounded corners */
  box-shadow: 0 0 3px rgba(0, 0, 0, 0.1);
  /* Apply a subtle shadow */
}

.chart_style {
  font: 'Poppins' !important;
  font-size: 80px !important;
}


td:first-child {
  position: sticky top;
  left: 0;
  z-index: 1
}


.absolute-full {
  /* background-color: rgba(21, 101, 192, 0.9); */
  background-color: rgba(20, 91, 162, 0.9);
  /* Blue color with 50% transparency */
  /* Blue color with 50% transparency */
  /* Yellow color with 50% transparency */
  /* z-index: 1000; */
  /* Adjust the z-index as needed */
}
</style>

