<template>
  <div>
    <q-list>
      <q-item-label header>
        <q-img src="../../assets/images/cm/cleverchap-logo.png" fit="scale-down" width="15rem" />
      </q-item-label>
      <q-separator spaced />
      <br />
      <q-scroll-area style="height: 100vh; max-width: 300px;" class="text-bold" text-color="primary">
        <q-item clickable tag="a" to="/dashboard">
          <q-item-section avatar>
            <q-icon name="dashboard" color="accent" />
          </q-item-section>

          <q-item-section color="grey-1">
            <q-item-label color="grey-1">Dashboard</q-item-label>
          </q-item-section>
        </q-item>

        <!-- <q-item-label header class="text-bold">Security and Attendance</q-item-label>

        <q-item clickable tag="a" to="/cleverchap/members">
          <q-item-section avatar>
            <q-icon name="fa-solid fa-person-circle-plus" color="secondary" />
          </q-item-section>
          <q-item-section color="grey-1">
            <q-item-label color="grey-1">Ward Drop Offs</q-item-label>
          </q-item-section>
        </q-item>
        <q-item clickable tag="a" to="/cleverchap/students">
          <q-item-section avatar>
            <q-icon name="fa-solid fa-person-circle-minus" color="secondary" />
          </q-item-section>
          <q-item-section color="grey-1">
            <q-item-label color="grey-1">Ward Pick Ups</q-item-label>
          </q-item-section>
        </q-item> -->

        <q-item-label header class="text-bold">Ward Management</q-item-label>

        <q-item clickable tag="a" to="/cleverchap/students">
          <q-item-section avatar>
            <q-icon name="fa-solid fa-people-group" color="secondary" />
          </q-item-section>
          <q-item-section color="grey-1">
            <q-item-label color="grey-1">Manage Students</q-item-label>
          </q-item-section>
        </q-item>

        <q-item clickable tag="a" to="/cleverchap/parents">
          <q-item-section avatar>
            <q-icon name="fa-solid fa-users-line" color="secondary" />
          </q-item-section>
          <q-item-section color="grey-1">
            <q-item-label color="grey-1">Parents or Delegates</q-item-label>
          </q-item-section>
        </q-item>

        <!-- <q-item-label header class="text-bold">User Management</q-item-label> -->

        <!-- <q-item clickable tag="a" to="/cleverchap/students">
          <q-item-section avatar>
            <q-icon name="fa-solid fa-users" color="secondary" />
          </q-item-section>
          <q-item-section color="grey-1">
            <q-item-label color="grey-1">Manage Users</q-item-label>
          </q-item-section>
        </q-item>

        <q-item clickable tag="a" to="/cleverchap/members">
          <q-item-section avatar>
            <q-icon name="fa-solid fa-file-lines" color="secondary" />
          </q-item-section>
          <q-item-section color="grey-1">
            <q-item-label color="grey-1">User Reporting</q-item-label>
          </q-item-section>
        </q-item> -->

        <!-- <q-item-label header class="text-bold">Account Settings</q-item-label>
        <q-item clickable tag="a" to="/cleverchap/manage-account">
          <q-item-section avatar>
            <q-icon name="manage_accounts" color="secondary" size="2rem" />
          </q-item-section><i class="fa-solid "></i>
          <q-item-section color="grey-1">
            <q-item-label color="grey-1">Manage Account Profile</q-item-label>
          </q-item-section>
        </q-item> -->

      </q-scroll-area>
    </q-list>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '../../stores/auth/auth-store';

const router = useRouter();
const store = useAuthStore();

</script>
