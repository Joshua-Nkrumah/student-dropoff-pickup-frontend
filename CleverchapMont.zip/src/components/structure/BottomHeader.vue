<template>
  <div></div>
  <div class="position-relative iq-banner ">
    <q-card class="q-pa-lg card-shadow card_container text-brand-white primary-color-light" square style="height: 200px">
      <div class="row q-px-lg" style="width: 100%; display: flex; flex-direction: row;">
      </div>
      <q-card-section>
        <div class="text-h5 text-weight-bold">Welcome</div>
      </q-card-section>
      <q-card-section class="q-pt-none text-weight-light">
        A Secure Student Pickup System by CleverChap
        <div>
          <q-btn round flat icon="arrow_back" label="Go Back" @click="goToBack" />
          <q-btn round style="margin-left: 1rem;" flat icon="arrow_forward" color="white" label="Go Forward"
            @click="goToForward" />
        </div>
      </q-card-section>

      <div class="create_member">
        <slot name="actions" />
      </div>
    </q-card>
  </div>
  <!-- <div class="background">
    <div style="min-height: 4rem">
      <slot />
    </div>
  </div> -->
</template>


<script lang="ts" setup>
import { useAuthStore } from 'src/stores/auth/auth-store';
import SideBarContent from 'components/structure/SideBarContent.vue';
import { useRouter } from 'vue-router';
import { ref } from 'vue';

const router = useRouter();
const authStore = useAuthStore();
const leftDrawerOpen = ref(false);
const toggleLeftDrawer = () => {
  leftDrawerOpen.value = !leftDrawerOpen.value;
};
const onLogout = () => {
  authStore.logout();
  router.push({ name: 'login' });
};
const store = useAuthStore();
const searchKey = ref('');
const goToBack = () => {
  router.back();
};
const goToForward = () => {
  router.forward();
};
</script>


<style scoped>
@import '../../css/hope-ui.css';
@import '../../css/custom.min.css';
@import '../../css/hope-ui.min.css';
/* @import '../../css/customizer.min.css'; */
/* @import '../../css/dark.min.css'; */
@import '../../css/core/libs.min.css';

.no_border_radius {
  border-radius: 0px !important;
}

.text-white {
  color: #ffffff !important;
}

.create_member {
  background-color: #ffffff;
  position: absolute;
  left: 85% !important;
  top: 5rem;
  width: fit-content;
  color: #1976D2;
}
</style>
