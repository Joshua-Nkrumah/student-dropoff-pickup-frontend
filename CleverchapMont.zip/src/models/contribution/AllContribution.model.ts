export interface Contributions {
  status?:  string;
  message?: string;
  data?:    AllContributionData;
}

export interface AllContributionData {
  total?:   number;
  records?: ContributionRecord[];
}

export interface ContributionRecord {
  parent?:   ParentData;
  students?: StudentData;
}

export interface ParentData {
  parentId?:    string;
  studentId?:   string;
  firstName?:   string;
  lastName?:    string;
  email?:       string;
  nationality?: string;
  phone?:       string;
  address?:     string;
  status?:      string;
  type?:        string;
  createdAt?:   Date;
  updatedAt?:   Date;
  createdBy?:   string;
}

export interface StudentData {
  studentId?:         string;
  classId?:           string;
  studentNumber?:     string;
  firstName?:         string;
  lastName?:          string;
  dateOfBirth?:       Date;
  gender?:            string;
  status?:            string;
  emergencyContact?:  string;
  location?:          string;
  nationality?:       string;
  createdBy?:         string;
  medicalConditions?: string;
  createdAt?:         Date;
  updatedAt?:         Date;
}
