export interface Members {
  status?:  string;
  message?: string;
  data?:    MemberData;
}

export interface MemberData {
  total?:   number;
  records?: MemberRecords[];
}

export interface MemberRecords {
  studentId?:         string;
  classId?:           string;
  studentNumber?:     string;
  firstName?:         string;
  lastName?:          string;
  dateOfBirth?:       Date;
  gender?:            string;
  status?:            string;
  emergencyContact?:  string;
  location?:          string;
  nationality?:       string;
  createdBy?:         string;
  medicalConditions?: string;
  createdAt?:         Date;
  updatedAt?:         Date;
}




