export interface AllAttendance {
  status?:  string;
  message?: string;
  data?:    Data;
}

export interface Data {
  total?:   number;
  records?: AttendanceRecord[];
}

export interface AttendanceRecord {
  logId?:              string;
  studentId?:          string;
  parentId?:           string;
  delegateId?:         string;
  classId?:            string;
  activityType?:       string;
  authorizedDateTime?: string;
  authorizedName?:     string;
  relation?:           string;
  remarks?:            string;
  status?:             string;
  createdBy?:          string;
  createdAt?:          Date;
  updatedAt?:          Date;
}
