export interface Delegates {
  status?:  string;
  message?: string;
  data?:    AllDelegateData;
}

export interface AllDelegateData {
  total?:   number;
  records?: DelegateRecord[];
}

export interface DelegateRecord {
  authorizedDelegate?: AuthorizedDelegate;
  student?:            Student;
}

export interface AuthorizedDelegate {
  delegateId?:          string;
  studentId?:           string;
  firstName?:           string;
  lastName?:            string;
  status?:              string;
  email?:               string;
  phone?:               string;
  relationshipToChild?: string;
  createdBy?:           string;
  createdAt?:           Date;
  updatedAt?:           Date;
}

export interface Student {
  studentId?:         string;
  classId?:           string;
  studentNumber?:     string;
  firstName?:         string;
  lastName?:          string;
  dateOfBirth?:       Date;
  gender?:            string;
  status?:            string;
  emergencyContact?:  string;
  location?:          string;
  nationality?:       string;
  createdBy?:         string;
  medicalConditions?: string;
  createdAt?:         Date;
  updatedAt?:         Date;
}
