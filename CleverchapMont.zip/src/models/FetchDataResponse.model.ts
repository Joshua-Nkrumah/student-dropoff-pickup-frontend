export default class FetchDataResponse<Type> {
  public total = 0;
  public records: Type[] = [];
}
