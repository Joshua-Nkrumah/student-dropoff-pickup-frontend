export class VerificationResponse {
  status?:  string;
  message?: string;
  data?:    VerificationResponseData;
}

export default class VerificationResponseData {
  verificationId?:  any;
  logId?:          any;
}
