export class AssignedUserResource {
  status?:  string;
  message?: string;
  data?:    AssignedUserResourceData;
}

export class AssignedUserResourceData {
  username?:     string;
  accessToken?:  string;
  expiration?:   Date;
  refreshToken?: null;
  userResource?: UserResource;
}

export class UserResource {
  userName?:    string;
  email?:       string;
  firstName?:   string;
  lastName?:    string;
  fullName?:    string;
  phoneNumber?: string;
  role?:        string;
}

export class User {
  userId!: string;
  firstName!: string;
  middleName!: string;
  lastName!: string;
  username!: string;
  userRole!: null;
  branch!: null;
  branchCode!: null;
  department!: null;
  userUnit!: null;
  mobile!: null;
  email!: string;
  dateCreated!: null;
  accountStatus!: null;
  lastLogin!: null;
  authToken!: null;
  createdBy!: null;
  authStatus!: null;
  authDate!: null;
  authUser!: null;
  dateModified!: null;
  modifiedBy!: null;
  modifiedCount!: number;
}
