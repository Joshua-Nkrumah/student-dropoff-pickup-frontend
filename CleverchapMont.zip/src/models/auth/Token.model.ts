export default class TokenModel {
  public username!: string;
  public accessToken!: string;
  public refreshToken!: string;
}
