export default class LoginRequestModel {
  public username!: string;
  public password!: string;
}
