export default class UserModel {
  public username!: string;
  public firstName!: string;
  public lastName!: string;
  public role!: string;
}
