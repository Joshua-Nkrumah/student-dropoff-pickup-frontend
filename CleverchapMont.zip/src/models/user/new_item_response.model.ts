export default class NewApp {
  public UserMenuID!: string;
  public UserID!: string;
  public AppID!: string;
  public MenuID!: string;
  public Status!: BigInteger;
  public StatusLabel!: string;
  public DateCreated!: string;
  public ItemID!: string;
  public UserName!: string;
  public Rank!: BigInteger;
  public LastModified!: string;
}
